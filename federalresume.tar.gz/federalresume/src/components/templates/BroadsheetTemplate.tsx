import type { ResumeContent } from "@/types/resume";

export function BroadsheetTemplate({ data, accent }: { data: ResumeContent; accent: string }) {
  return (
    <div className="resume-template broadsheet" style={{ "--accent": accent } as React.CSSProperties}>
      <header>
        <h1>{data.name || "Your Name"}</h1>
        <div className="role">{data.role || "Your Title"}</div>
        <div className="contact">
          {[data.email, data.phone, data.location, data.website].filter(Boolean).join("  ·  ")}
        </div>
      </header>
      <hr />

      {data.summary && (
        <Section title="Summary">
          <p>{data.summary}</p>
        </Section>
      )}

      {data.experience.length > 0 && (
        <Section title="Experience">
          {data.experience.map((e) => (
            <article key={e.id} className="entry">
              <div className="entry-head">
                <strong>{e.role}</strong>
                <span className="dates">
                  {e.start}{e.end ? ` — ${e.end}` : ""}
                </span>
              </div>
              <div className="entry-sub">
                {e.company}
                {e.location ? ` · ${e.location}` : ""}
              </div>
              <ul>
                {e.bullets.map((b, i) => (
                  <li key={i}>{b}</li>
                ))}
              </ul>
            </article>
          ))}
        </Section>
      )}

      {data.education.length > 0 && (
        <Section title="Education">
          {data.education.map((e) => (
            <article key={e.id} className="entry">
              <div className="entry-head">
                <strong>{e.school}</strong>
                <span className="dates">
                  {e.start}{e.end ? ` — ${e.end}` : ""}
                </span>
              </div>
              <div className="entry-sub">{e.degree}</div>
              {e.notes && <p>{e.notes}</p>}
            </article>
          ))}
        </Section>
      )}

      {data.skills.length > 0 && (
        <Section title="Skills">
          <p className="skills">{data.skills.join("  ·  ")}</p>
        </Section>
      )}

      <style jsx>{`
        .resume-template {
          background: white;
          color: #1b1916;
          font-family: "Fraunces", Georgia, serif;
          padding: 56px 64px;
          line-height: 1.45;
          font-size: 11pt;
        }
        header h1 {
          font-size: 28pt;
          font-weight: 600;
          letter-spacing: -0.02em;
          margin: 0;
        }
        header .role {
          font-family: "IBM Plex Mono", monospace;
          font-size: 9pt;
          letter-spacing: 0.14em;
          text-transform: uppercase;
          color: var(--accent);
          margin-top: 4px;
        }
        header .contact {
          font-family: "IBM Plex Sans", sans-serif;
          font-size: 9.5pt;
          color: #3a352d;
          margin-top: 6px;
        }
        hr {
          border: 0;
          border-top: 1px solid #1b1916;
          margin: 14px 0 18px;
        }
        :global(.entry) {
          margin-bottom: 14px;
        }
        :global(.entry-head) {
          display: flex;
          justify-content: space-between;
          align-items: baseline;
          font-size: 11.5pt;
        }
        :global(.entry-sub) {
          font-style: italic;
          color: #6e6557;
          font-size: 10.5pt;
          margin-bottom: 4px;
        }
        :global(.dates) {
          font-family: "IBM Plex Mono", monospace;
          font-size: 9pt;
          letter-spacing: 0.06em;
          color: #6e6557;
        }
        :global(ul) {
          padding-left: 16px;
          margin: 4px 0 0;
        }
        :global(li) {
          margin-bottom: 3px;
        }
        :global(.skills) {
          font-size: 10.5pt;
          color: #3a352d;
        }
      `}</style>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section style={{ marginBottom: 18 }}>
      <h2
        style={{
          fontFamily: '"IBM Plex Mono", monospace',
          fontSize: "9pt",
          letterSpacing: "0.18em",
          textTransform: "uppercase",
          color: "var(--accent)",
          fontWeight: 500,
          margin: "0 0 8px",
        }}
      >
        {title}
      </h2>
      {children}
    </section>
  );
}
