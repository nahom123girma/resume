import { BroadsheetTemplate } from "./BroadsheetTemplate";
import { SidebarTemplate } from "./SidebarTemplate";
import { EditorialTemplate } from "./EditorialTemplate";
import { WhisperTemplate } from "./WhisperTemplate";
import type { ResumeContent } from "@/types/resume";

type Props = { id: string; data: ResumeContent; accent: string };

export function ResumeTemplate({ id, data, accent }: Props) {
  switch (id) {
    case "sidebar":
      return <SidebarTemplate data={data} accent={accent} />;
    case "editorial":
      return <EditorialTemplate data={data} accent={accent} />;
    case "whisper":
      return <WhisperTemplate data={data} accent={accent} />;
    case "broadsheet":
    default:
      return <BroadsheetTemplate data={data} accent={accent} />;
  }
}

export { BroadsheetTemplate, SidebarTemplate, EditorialTemplate, WhisperTemplate };
