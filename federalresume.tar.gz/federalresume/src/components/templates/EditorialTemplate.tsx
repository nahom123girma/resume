import type { ResumeContent } from "@/types/resume";

export function EditorialTemplate({ data, accent }: { data: ResumeContent; accent: string }) {
  return (
    <div className="resume-editorial" style={{ "--accent": accent } as React.CSSProperties}>
      <header>
        <h1>{data.name || "Your Name"}</h1>
        <div className="role">{data.role || "Your Title"}</div>
      </header>

      <div className="cols">
        <aside>
          <div className="block">
            <h3>Contact</h3>
            {data.email && <div>{data.email}</div>}
            {data.phone && <div>{data.phone}</div>}
            {data.location && <div>{data.location}</div>}
            {data.website && <div>{data.website}</div>}
          </div>
          {data.skills.length > 0 && (
            <div className="block">
              <h3>Skills</h3>
              {data.skills.map((s) => (
                <div key={s}>{s}</div>
              ))}
            </div>
          )}
          {data.education.length > 0 && (
            <div className="block">
              <h3>Education</h3>
              {data.education.map((e) => (
                <div key={e.id} className="edu">
                  <strong>{e.school}</strong>
                  <div>{e.degree}</div>
                  <div className="dates">
                    {e.start}{e.end ? ` — ${e.end}` : ""}
                  </div>
                </div>
              ))}
            </div>
          )}
        </aside>

        <main>
          {data.summary && (
            <section>
              <h3>Summary</h3>
              <p>{data.summary}</p>
            </section>
          )}
          {data.experience.length > 0 && (
            <section>
              <h3>Experience</h3>
              {data.experience.map((e) => (
                <article key={e.id} className="entry">
                  <div className="entry-head">
                    <strong>{e.role}</strong>
                    <span className="dates">
                      {e.start}{e.end ? ` — ${e.end}` : ""}
                    </span>
                  </div>
                  <div className="entry-sub">
                    {e.company}
                    {e.location ? ` · ${e.location}` : ""}
                  </div>
                  <ul>
                    {e.bullets.map((b, i) => (
                      <li key={i}>{b}</li>
                    ))}
                  </ul>
                </article>
              ))}
            </section>
          )}
        </main>
      </div>

      <style jsx>{`
        .resume-editorial {
          background: #faf6ec;
          color: #1b1916;
          font-family: "Fraunces", Georgia, serif;
          padding: 56px 60px;
          font-size: 10.5pt;
          line-height: 1.5;
        }
        header h1 {
          font-style: italic;
          font-weight: 400;
          font-size: 44pt;
          line-height: 0.95;
          letter-spacing: -0.03em;
          margin: 0 0 6px;
        }
        header .role {
          font-family: "IBM Plex Mono", monospace;
          font-style: normal;
          font-size: 9pt;
          letter-spacing: 0.18em;
          text-transform: uppercase;
          color: var(--accent);
          margin-bottom: 24px;
        }
        .cols {
          display: grid;
          grid-template-columns: 200px 1fr;
          gap: 36px;
        }
        aside .block {
          margin-bottom: 22px;
          font-size: 10pt;
          line-height: 1.55;
        }
        h3 {
          font-family: "IBM Plex Mono", monospace;
          font-size: 8.5pt;
          letter-spacing: 0.18em;
          text-transform: uppercase;
          color: #1b1916;
          font-weight: 500;
          margin: 0 0 8px;
        }
        main :global(section) {
          margin-bottom: 22px;
        }
        main :global(h3) {
          color: var(--accent);
        }
        main :global(.entry) {
          margin-bottom: 14px;
        }
        main :global(.entry-head) {
          display: flex;
          justify-content: space-between;
          align-items: baseline;
          font-size: 12pt;
        }
        main :global(.entry-sub) {
          font-style: italic;
          color: #6e6557;
          font-size: 10pt;
          margin-bottom: 4px;
        }
        main :global(.dates) {
          font-family: "IBM Plex Mono", monospace;
          font-size: 9pt;
          letter-spacing: 0.06em;
          color: #6e6557;
        }
        main :global(ul) {
          padding-left: 16px;
          margin: 4px 0 0;
        }
        aside :global(.dates) {
          font-family: "IBM Plex Mono", monospace;
          font-size: 8.5pt;
          color: #6e6557;
        }
      `}</style>
    </div>
  );
}
