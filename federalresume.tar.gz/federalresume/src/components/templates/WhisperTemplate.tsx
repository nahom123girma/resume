import type { ResumeContent } from "@/types/resume";

export function WhisperTemplate({ data, accent }: { data: ResumeContent; accent: string }) {
  return (
    <div className="resume-whisper" style={{ "--accent": accent } as React.CSSProperties}>
      <header>
        <h1>{(data.name || "your name").toLowerCase()}.</h1>
        <div className="role">{(data.role || "your title").toLowerCase()}</div>
        <div className="contact">
          {[data.email, data.phone, data.location, data.website].filter(Boolean).join("  /  ")}
        </div>
      </header>

      {data.summary && (
        <section>
          <h2>summary</h2>
          <p>{data.summary}</p>
        </section>
      )}

      {data.experience.length > 0 && (
        <section>
          <h2>work</h2>
          {data.experience.map((e) => (
            <article key={e.id} className="entry">
              <div className="entry-head">
                <span>
                  <strong>{e.role}</strong>, {e.company}
                </span>
                <span className="dates">
                  {e.start}{e.end ? ` — ${e.end}` : ""}
                </span>
              </div>
              <ul>
                {e.bullets.map((b, i) => (
                  <li key={i}>{b}</li>
                ))}
              </ul>
            </article>
          ))}
        </section>
      )}

      {data.education.length > 0 && (
        <section>
          <h2>education</h2>
          {data.education.map((e) => (
            <div key={e.id} className="entry">
              <div className="entry-head">
                <span>
                  <strong>{e.school}</strong>, {e.degree}
                </span>
                <span className="dates">
                  {e.start}{e.end ? ` — ${e.end}` : ""}
                </span>
              </div>
            </div>
          ))}
        </section>
      )}

      {data.skills.length > 0 && (
        <section>
          <h2>tools</h2>
          <p>{data.skills.join(", ")}</p>
        </section>
      )}

      <style jsx>{`
        .resume-whisper {
          background: white;
          color: #1b1916;
          font-family: "IBM Plex Sans", sans-serif;
          padding: 64px 64px;
          font-size: 10.5pt;
          line-height: 1.55;
        }
        header h1 {
          font-size: 22pt;
          font-weight: 500;
          letter-spacing: -0.01em;
          margin: 0;
        }
        header .role {
          font-size: 10pt;
          color: #6e6557;
          margin-top: 2px;
        }
        header .contact {
          font-size: 9.5pt;
          color: #6e6557;
          margin-top: 14px;
          margin-bottom: 32px;
        }
        section {
          margin-bottom: 22px;
        }
        h2 {
          font-size: 10pt;
          font-weight: 500;
          color: #1b1916;
          margin: 0 0 10px;
        }
        h2::after {
          content: "";
          display: inline-block;
          width: 16px;
          height: 1px;
          background: var(--accent);
          margin-left: 10px;
          vertical-align: middle;
        }
        .entry {
          margin-bottom: 12px;
        }
        .entry-head {
          display: flex;
          justify-content: space-between;
          align-items: baseline;
          font-size: 10.5pt;
        }
        .dates {
          font-size: 9pt;
          color: #6e6557;
        }
        ul {
          padding-left: 16px;
          margin: 4px 0 0;
          color: #3a352d;
        }
        li {
          margin-bottom: 2px;
        }
      `}</style>
    </div>
  );
}
