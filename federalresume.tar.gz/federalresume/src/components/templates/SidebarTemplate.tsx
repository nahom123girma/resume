import type { ResumeContent } from "@/types/resume";

export function SidebarTemplate({ data, accent }: { data: ResumeContent; accent: string }) {
  return (
    <div className="resume-sidebar" style={{ "--accent": accent } as React.CSSProperties}>
      <aside className="rail">
        <div className="rail-name">{data.name || "Your Name"}</div>
        <div className="rail-role">{data.role || "Your Title"}</div>

        <div className="rail-section">
          <h3>Contact</h3>
          {data.email && <div>{data.email}</div>}
          {data.phone && <div>{data.phone}</div>}
          {data.location && <div>{data.location}</div>}
          {data.website && <div>{data.website}</div>}
        </div>

        {data.skills.length > 0 && (
          <div className="rail-section">
            <h3>Skills</h3>
            {data.skills.map((s) => (
              <div key={s}>{s}</div>
            ))}
          </div>
        )}

        {data.education.length > 0 && (
          <div className="rail-section">
            <h3>Education</h3>
            {data.education.map((e) => (
              <div key={e.id} className="rail-edu">
                <strong>{e.school}</strong>
                <div>{e.degree}</div>
                <div className="rail-dates">
                  {e.start}{e.end ? ` — ${e.end}` : ""}
                </div>
              </div>
            ))}
          </div>
        )}
      </aside>

      <main className="body">
        {data.summary && (
          <section>
            <h2>Summary</h2>
            <p>{data.summary}</p>
          </section>
        )}

        {data.experience.length > 0 && (
          <section>
            <h2>Experience</h2>
            {data.experience.map((e) => (
              <article key={e.id} className="entry">
                <div className="entry-head">
                  <strong>{e.role}</strong>
                  <span className="dates">
                    {e.start}{e.end ? ` — ${e.end}` : ""}
                  </span>
                </div>
                <div className="entry-sub">
                  {e.company}
                  {e.location ? ` · ${e.location}` : ""}
                </div>
                <ul>
                  {e.bullets.map((b, i) => (
                    <li key={i}>{b}</li>
                  ))}
                </ul>
              </article>
            ))}
          </section>
        )}
      </main>

      <style jsx>{`
        .resume-sidebar {
          background: white;
          color: #1b1916;
          font-family: "IBM Plex Sans", sans-serif;
          display: grid;
          grid-template-columns: 220px 1fr;
          font-size: 10.5pt;
          line-height: 1.45;
          min-height: 100%;
        }
        .rail {
          background: var(--accent);
          color: #faf6ec;
          padding: 48px 26px;
        }
        .rail-name {
          font-family: "Fraunces", serif;
          font-size: 22pt;
          font-weight: 600;
          line-height: 1.05;
          letter-spacing: -0.02em;
          margin-bottom: 4px;
        }
        .rail-role {
          font-size: 9pt;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          opacity: 0.8;
          margin-bottom: 28px;
        }
        .rail-section {
          margin-bottom: 22px;
          font-size: 9.5pt;
          line-height: 1.6;
        }
        .rail-section h3 {
          font-family: "IBM Plex Mono", monospace;
          font-size: 8.5pt;
          letter-spacing: 0.18em;
          text-transform: uppercase;
          opacity: 0.85;
          margin: 0 0 6px;
          font-weight: 500;
        }
        .rail-edu {
          margin-bottom: 8px;
        }
        .rail-dates {
          font-family: "IBM Plex Mono", monospace;
          font-size: 8pt;
          opacity: 0.75;
        }
        .body {
          padding: 48px 56px;
        }
        .body :global(section) {
          margin-bottom: 22px;
        }
        .body :global(h2) {
          font-family: "IBM Plex Mono", monospace;
          font-size: 9pt;
          letter-spacing: 0.18em;
          text-transform: uppercase;
          color: var(--accent);
          font-weight: 500;
          margin: 0 0 10px;
        }
        .body :global(.entry) {
          margin-bottom: 14px;
        }
        .body :global(.entry-head) {
          display: flex;
          justify-content: space-between;
          align-items: baseline;
          font-family: "Fraunces", serif;
          font-size: 12pt;
        }
        .body :global(.entry-sub) {
          font-style: italic;
          color: #6e6557;
          font-size: 10pt;
        }
        .body :global(.dates) {
          font-family: "IBM Plex Mono", monospace;
          font-size: 9pt;
          letter-spacing: 0.06em;
          color: #6e6557;
        }
        .body :global(ul) {
          padding-left: 16px;
          margin: 4px 0 0;
        }
        .body :global(li) {
          margin-bottom: 3px;
        }
      `}</style>
    </div>
  );
}
