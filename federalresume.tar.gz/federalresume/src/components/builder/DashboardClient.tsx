"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { signOut } from "next-auth/react";

type ResumeRow = {
  id: string;
  title: string;
  templateId: string;
  accentColor: string;
  updatedAt: string;
};

export function DashboardClient({ initialResumes }: { initialResumes: ResumeRow[] }) {
  const router = useRouter();
  const [resumes, setResumes] = useState(initialResumes);
  const [creating, setCreating] = useState(false);

  async function createResume(sample = false) {
    setCreating(true);
    const res = await fetch("/api/resumes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sample }),
    });
    setCreating(false);
    if (!res.ok) return alert("Could not create résumé");
    const { resume } = await res.json();
    router.push(`/resume/${resume.id}`);
  }

  async function deleteResume(id: string) {
    if (!confirm("Delete this résumé permanently?")) return;
    const res = await fetch(`/api/resumes/${id}`, { method: "DELETE" });
    if (res.ok) setResumes((rs) => rs.filter((r) => r.id !== id));
  }

  return (
    <>
      <div className="mb-10 grid gap-3 sm:grid-cols-2">
        <button
          onClick={() => createResume(false)}
          disabled={creating}
          className="group flex items-center justify-between gap-4 rounded-2xl border border-rule bg-paper p-6 text-left transition-all hover:-translate-y-0.5 hover:border-ink hover:shadow-soft disabled:opacity-60"
        >
          <div>
            <div className="mb-1 font-mono text-[11px] uppercase tracking-[0.14em] text-ink-mute">Start fresh</div>
            <div className="font-serif text-[22px] font-medium leading-[1.15] tracking-tightish">
              Create a new résumé
            </div>
          </div>
          <span className="text-2xl text-amber transition-transform group-hover:translate-x-1">→</span>
        </button>

        <button
          onClick={() => createResume(true)}
          disabled={creating}
          className="group flex items-center justify-between gap-4 rounded-2xl border border-rule bg-cream-2 p-6 text-left transition-all hover:-translate-y-0.5 hover:border-ink hover:shadow-soft disabled:opacity-60"
        >
          <div>
            <div className="mb-1 font-mono text-[11px] uppercase tracking-[0.14em] text-ink-mute">Quick start</div>
            <div className="font-serif text-[22px] font-medium italic leading-[1.15] tracking-tightish">
              Use the sample, edit from there
            </div>
          </div>
          <span className="text-2xl text-amber transition-transform group-hover:translate-x-1">→</span>
        </button>
      </div>

      {resumes.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-rule bg-paper p-10 text-center">
          <p className="font-serif text-[20px] italic text-ink-soft">
            No résumés yet. Pick one of the cards above and we&rsquo;ll get you started.
          </p>
        </div>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {resumes.map((r) => (
            <ResumeCard key={r.id} resume={r} onDelete={() => deleteResume(r.id)} />
          ))}
        </div>
      )}

      <div className="mt-12 flex justify-end">
        <button
          onClick={() => signOut({ callbackUrl: "/" })}
          className="text-sm text-ink-soft transition-colors hover:text-amber"
        >
          Sign out
        </button>
      </div>
    </>
  );
}

function ResumeCard({ resume, onDelete }: { resume: ResumeRow; onDelete: () => void }) {
  return (
    <div className="group relative overflow-hidden rounded-2xl border border-rule bg-paper p-5 transition-all hover:-translate-y-0.5 hover:border-ink hover:shadow-soft">
      <div className="mb-4 flex h-32 items-center justify-center rounded-lg" style={{ background: resume.accentColor }}>
        <div className="rounded bg-white p-3 font-serif text-[10px] shadow-soft">
          <div className="font-semibold">{resume.title.slice(0, 24) || "Untitled"}</div>
          <div className="my-1 h-px bg-ink" />
          <div className="h-1 w-20 rounded bg-cream-2" />
          <div className="mt-1 h-1 w-14 rounded bg-cream-2" />
        </div>
      </div>
      <div className="font-serif text-[18px] font-medium leading-tight tracking-tightish">{resume.title}</div>
      <div className="mt-1 font-mono text-[10px] uppercase tracking-[0.14em] text-ink-mute">
        {resume.templateId} · updated {new Date(resume.updatedAt).toLocaleDateString()}
      </div>
      <div className="mt-4 flex gap-2">
        <Link
          href={`/resume/${resume.id}`}
          className="flex-1 rounded-full bg-ink px-4 py-2 text-center text-xs font-medium text-cream transition-colors hover:bg-amber"
        >
          Open
        </Link>
        <a
          href={`/api/resumes/${resume.id}/pdf`}
          className="rounded-full border border-ink px-4 py-2 text-center text-xs font-medium text-ink transition-colors hover:bg-ink hover:text-cream"
        >
          PDF
        </a>
        <button
          onClick={onDelete}
          className="rounded-full px-3 py-2 text-xs text-ink-mute transition-colors hover:text-amber-deep"
          aria-label="Delete résumé"
        >
          ✕
        </button>
      </div>
    </div>
  );
}
