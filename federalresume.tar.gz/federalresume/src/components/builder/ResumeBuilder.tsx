"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ResumeTemplate } from "@/components/templates";
import { templates, accentSwatches } from "@/lib/templates";
import type { ResumeContent, ResumeEducation, ResumeExperience } from "@/types/resume";

type Props = {
  id: string;
  initialTitle: string;
  initialTemplateId: string;
  initialAccent: string;
  initialContent: ResumeContent;
};

type SaveState = "idle" | "saving" | "saved" | "error";

export function ResumeBuilder({ id, initialTitle, initialTemplateId, initialAccent, initialContent }: Props) {
  const [title, setTitle] = useState(initialTitle);
  const [templateId, setTemplateId] = useState(initialTemplateId);
  const [accent, setAccent] = useState(initialAccent);
  const [content, setContent] = useState<ResumeContent>(initialContent);
  const [saveState, setSaveState] = useState<SaveState>("idle");
  const [previewOpen, setPreviewOpen] = useState(false);
  const [downloading, setDownloading] = useState(false);

  // Autosave with debounce. Schedules a save 5s after the last change; also runs on unmount.
  const dirtyRef = useRef(false);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const latest = useRef({ title, templateId, accent, content });
  latest.current = { title, templateId, accent, content };

  const persist = useCallback(async () => {
    setSaveState("saving");
    try {
      const res = await fetch(`/api/resumes/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(latest.current),
      });
      if (!res.ok) throw new Error(await res.text());
      setSaveState("saved");
      dirtyRef.current = false;
    } catch (e) {
      console.error(e);
      setSaveState("error");
    }
  }, [id]);

  useEffect(() => {
    dirtyRef.current = true;
    setSaveState((s) => (s === "error" ? s : "idle"));
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      void persist();
    }, 5000);
    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
    };
  }, [title, templateId, accent, content, persist]);

  // Save on unload if dirty.
  useEffect(() => {
    const onUnload = () => {
      if (!dirtyRef.current) return;
      navigator.sendBeacon?.(
        `/api/resumes/${id}`,
        new Blob([JSON.stringify(latest.current)], { type: "application/json" })
      );
    };
    window.addEventListener("beforeunload", onUnload);
    return () => window.removeEventListener("beforeunload", onUnload);
  }, [id]);

  const update = useCallback(<K extends keyof ResumeContent>(key: K, value: ResumeContent[K]) => {
    setContent((c) => ({ ...c, [key]: value }));
  }, []);

  const headerInfo = useMemo(() => {
    if (saveState === "saving") return "Saving…";
    if (saveState === "saved") return "Saved";
    if (saveState === "error") return "Save failed — retry";
    return "Autosave on";
  }, [saveState]);

  async function downloadPdf() {
    setDownloading(true);
    await persist();
    setDownloading(false);
    window.open(`/api/resumes/${id}/pdf`, "_blank");
  }

  return (
    <div className="min-h-screen bg-cream">
      <header className="sticky top-0 z-30 flex flex-wrap items-center justify-between gap-3 border-b border-rule bg-cream/95 px-4 py-3 backdrop-blur md:px-8">
        <div className="flex items-center gap-3">
          <Link href="/dashboard" className="font-serif text-[20px] font-semibold tracking-[-0.02em]">
            ← Back
          </Link>
          <span className="text-ink-mute">·</span>
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="bg-transparent font-serif text-[20px] font-medium tracking-tightish outline-none focus:border-b focus:border-ink"
            placeholder="Untitled résumé"
          />
        </div>
        <div className="flex items-center gap-3">
          <span
            className={`font-mono text-[11px] uppercase tracking-[0.14em] ${
              saveState === "error" ? "text-amber-deep" : "text-ink-mute"
            }`}
            onClick={saveState === "error" ? () => persist() : undefined}
            role={saveState === "error" ? "button" : undefined}
          >
            {headerInfo}
          </span>
          <button
            onClick={() => persist()}
            className="rounded-full border border-ink px-4 py-2 text-xs font-medium text-ink transition-colors hover:bg-ink hover:text-cream"
          >
            Save now
          </button>
          <button
            onClick={downloadPdf}
            disabled={downloading}
            className="inline-flex items-center gap-2 rounded-full bg-amber px-4 py-2 text-xs font-medium text-paper transition-all hover:-translate-y-px hover:bg-amber-deep disabled:opacity-60"
          >
            {downloading ? "Preparing…" : "↓ Download PDF"}
          </button>
          <button
            onClick={() => setPreviewOpen((v) => !v)}
            className="rounded-full border border-ink px-3 py-2 text-xs text-ink lg:hidden"
          >
            {previewOpen ? "Edit" : "Preview"}
          </button>
        </div>
      </header>

      <div className="grid lg:grid-cols-2">
        {/* EDITOR */}
        <div className={`${previewOpen ? "hidden" : "block"} lg:block`}>
          <div className="mx-auto max-w-[640px] px-5 py-10">
            <SectionHead label="Style" />
            <TemplateSwitcher value={templateId} onChange={setTemplateId} />

            <div className="mb-8 mt-5 flex items-center gap-2">
              <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-ink-mute">Accent</span>
              <div className="flex gap-2">
                {accentSwatches.map((c) => (
                  <button
                    key={c}
                    onClick={() => setAccent(c)}
                    aria-label={`Use ${c}`}
                    className={`h-6 w-6 rounded-full border transition-transform hover:scale-110 ${
                      accent === c ? "ring-2 ring-ink ring-offset-2 ring-offset-cream" : "border-rule"
                    }`}
                    style={{ background: c }}
                  />
                ))}
              </div>
            </div>

            <SectionHead label="Header" />
            <div className="mb-8 grid gap-3">
              <Field
                value={content.name}
                onChange={(v) => update("name", v)}
                placeholder="Maya Hernandez"
                label="Full name"
              />
              <Field
                value={content.role}
                onChange={(v) => update("role", v)}
                placeholder="Senior Product Designer"
                label="Title"
              />
              <div className="grid grid-cols-2 gap-3">
                <Field value={content.email} onChange={(v) => update("email", v)} placeholder="you@email.com" label="Email" />
                <Field value={content.phone} onChange={(v) => update("phone", v)} placeholder="(555) 555-5555" label="Phone" />
                <Field value={content.location} onChange={(v) => update("location", v)} placeholder="City, State" label="Location" />
                <Field
                  value={content.website}
                  onChange={(v) => update("website", v)}
                  placeholder="federalresume.com/you"
                  label="Website"
                />
              </div>
            </div>

            <SectionHead label="Summary" />
            <div className="mb-8">
              <Textarea
                rows={4}
                value={content.summary}
                onChange={(v) => update("summary", v)}
                placeholder="A short paragraph that introduces who you are and what you do best."
              />
            </div>

            <SectionHead
              label="Experience"
              action={
                <SmallAdd
                  onClick={() =>
                    update("experience", [
                      ...content.experience,
                      newExperience(),
                    ])
                  }
                />
              }
            />
            <div className="mb-8 flex flex-col gap-5">
              {content.experience.length === 0 && <Empty>Add a role to begin.</Empty>}
              {content.experience.map((e, i) => (
                <ExperienceEditor
                  key={e.id}
                  exp={e}
                  onChange={(next) => {
                    const arr = [...content.experience];
                    arr[i] = next;
                    update("experience", arr);
                  }}
                  onRemove={() => update("experience", content.experience.filter((_, j) => j !== i))}
                />
              ))}
            </div>

            <SectionHead
              label="Education"
              action={
                <SmallAdd
                  onClick={() =>
                    update("education", [...content.education, newEducation()])
                  }
                />
              }
            />
            <div className="mb-8 flex flex-col gap-5">
              {content.education.length === 0 && <Empty>Add a school or program.</Empty>}
              {content.education.map((e, i) => (
                <EducationEditor
                  key={e.id}
                  edu={e}
                  onChange={(next) => {
                    const arr = [...content.education];
                    arr[i] = next;
                    update("education", arr);
                  }}
                  onRemove={() => update("education", content.education.filter((_, j) => j !== i))}
                />
              ))}
            </div>

            <SectionHead label="Skills" />
            <div className="mb-16">
              <SkillsEditor value={content.skills} onChange={(v) => update("skills", v)} />
            </div>
          </div>
        </div>

        {/* PREVIEW */}
        <div className={`${previewOpen ? "block" : "hidden"} lg:block`}>
          <div className="sticky top-[64px] h-[calc(100vh-64px)] overflow-auto bg-cream-2 p-6">
            <div className="mx-auto aspect-[8.5/11] w-full max-w-[820px] origin-top scale-[var(--zoom,1)] overflow-hidden rounded-md bg-white shadow-lg">
              <ResumeTemplate id={templateId} data={content} accent={accent} />
            </div>
          </div>
        </div>
      </div>

      {/* Floating save FAB */}
      <button
        onClick={() => persist()}
        aria-label="Save résumé"
        className="fixed bottom-6 left-6 z-30 hidden h-12 w-12 items-center justify-center rounded-full bg-ink text-cream shadow-lg transition-all hover:-translate-y-0.5 hover:bg-amber lg:flex"
      >
        ✓
      </button>
    </div>
  );
}

/* ────────────────────────── Sub-components ────────────────────────── */

function SectionHead({ label, action }: { label: string; action?: React.ReactNode }) {
  return (
    <div className="mb-3 flex items-center justify-between">
      <h2 className="font-mono text-[11px] uppercase tracking-[0.18em] text-ink-mute">{label}</h2>
      {action}
    </div>
  );
}

function SmallAdd({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex h-7 w-7 items-center justify-center rounded-full bg-ink text-[14px] text-cream transition-colors hover:bg-amber"
    >
      +
    </button>
  );
}

function Empty({ children }: { children: React.ReactNode }) {
  return <p className="text-sm italic text-ink-mute">{children}</p>;
}

function Field({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <label className="flex flex-col gap-1">
      <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-ink-mute">{label}</span>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="rounded-md border border-rule bg-paper px-3 py-2 text-[14.5px] text-ink outline-none transition-colors focus:border-ink"
      />
    </label>
  );
}

function Textarea({
  value,
  onChange,
  placeholder,
  rows = 3,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  rows?: number;
}) {
  return (
    <textarea
      value={value}
      rows={rows}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="w-full resize-y rounded-md border border-rule bg-paper px-3 py-2 text-[14.5px] leading-[1.55] text-ink outline-none transition-colors focus:border-ink"
    />
  );
}

function ExperienceEditor({
  exp,
  onChange,
  onRemove,
}: {
  exp: ResumeExperience;
  onChange: (next: ResumeExperience) => void;
  onRemove: () => void;
}) {
  const set = (k: keyof ResumeExperience, v: string | string[]) => onChange({ ...exp, [k]: v });

  function setBullet(i: number, v: string) {
    const next = [...exp.bullets];
    next[i] = v;
    set("bullets", next);
  }
  function addBullet() {
    set("bullets", [...exp.bullets, ""]);
  }
  function removeBullet(i: number) {
    set("bullets", exp.bullets.filter((_, j) => j !== i));
  }

  return (
    <div className="rounded-xl border border-rule bg-paper p-4">
      <div className="mb-3 grid gap-2 md:grid-cols-2">
        <Field label="Role" value={exp.role} onChange={(v) => set("role", v)} placeholder="Senior Product Designer" />
        <Field label="Company" value={exp.company} onChange={(v) => set("company", v)} placeholder="Acme Cloud" />
        <Field
          label="Location"
          value={exp.location ?? ""}
          onChange={(v) => set("location", v)}
          placeholder="Remote"
        />
        <div className="grid grid-cols-2 gap-2">
          <Field label="Start" value={exp.start} onChange={(v) => set("start", v)} placeholder="Jan 2022" />
          <Field label="End" value={exp.end} onChange={(v) => set("end", v)} placeholder="Present" />
        </div>
      </div>

      <div className="mb-2 flex items-center justify-between">
        <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-ink-mute">Bullets</span>
        <button onClick={addBullet} className="text-xs text-amber hover:underline">
          + bullet
        </button>
      </div>
      <div className="flex flex-col gap-2">
        {exp.bullets.map((b, i) => (
          <BulletEditor
            key={i}
            value={b}
            roleContext={exp.role}
            onChange={(v) => setBullet(i, v)}
            onRemove={() => removeBullet(i)}
          />
        ))}
      </div>

      <div className="mt-3 flex justify-end">
        <button onClick={onRemove} className="text-xs text-ink-mute transition-colors hover:text-amber-deep">
          Remove role
        </button>
      </div>
    </div>
  );
}

function BulletEditor({
  value,
  roleContext,
  onChange,
  onRemove,
}: {
  value: string;
  roleContext: string;
  onChange: (v: string) => void;
  onRemove: () => void;
}) {
  const [loading, setLoading] = useState(false);
  const [rewrites, setRewrites] = useState<string[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function enhance() {
    if (!value || value.trim().length < 3) {
      setError("Write a draft first — even a rough one.");
      return;
    }
    setError(null);
    setLoading(true);
    setRewrites(null);
    try {
      const res = await fetch("/api/ai/enhance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: value, context: roleContext }),
      });
      const body = await res.json();
      if (!res.ok) throw new Error(body.error || "AI request failed");
      setRewrites(body.rewrites ?? []);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : "AI request failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <div className="flex items-start gap-2">
        <textarea
          rows={2}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="flex-1 resize-y rounded-md border border-rule bg-cream-2/40 px-3 py-2 text-[14px] leading-[1.5] outline-none transition-colors focus:border-ink"
          placeholder="Led X to achieve Y, resulting in Z."
        />
        <div className="flex flex-col gap-1">
          <button
            onClick={enhance}
            disabled={loading}
            className="whitespace-nowrap rounded-full border border-amber bg-amber/5 px-3 py-1.5 text-[11px] font-medium text-amber transition-colors hover:bg-amber hover:text-paper disabled:opacity-60"
            title="Rewrite with AI"
          >
            {loading ? "…" : "✦ AI"}
          </button>
          <button
            onClick={onRemove}
            className="rounded-full px-3 py-1.5 text-[11px] text-ink-mute hover:text-amber-deep"
            aria-label="Remove bullet"
          >
            ✕
          </button>
        </div>
      </div>

      {error && <p className="mt-1 text-xs text-amber-deep">{error}</p>}

      {rewrites && rewrites.length > 0 && (
        <div className="mt-2 rounded-md border border-amber/40 bg-amber/5 p-2">
          <div className="mb-1 font-mono text-[10px] uppercase tracking-[0.14em] text-amber">
            Pick one to replace
          </div>
          <ul className="flex flex-col gap-1">
            {rewrites.map((r, i) => (
              <li key={i}>
                <button
                  onClick={() => {
                    onChange(r);
                    setRewrites(null);
                  }}
                  className="w-full rounded border border-rule bg-paper p-2 text-left text-[13.5px] leading-[1.5] hover:border-ink"
                >
                  {r}
                </button>
              </li>
            ))}
            <li>
              <button onClick={() => setRewrites(null)} className="text-xs text-ink-mute hover:underline">
                Dismiss
              </button>
            </li>
          </ul>
        </div>
      )}
    </div>
  );
}

function EducationEditor({
  edu,
  onChange,
  onRemove,
}: {
  edu: ResumeEducation;
  onChange: (next: ResumeEducation) => void;
  onRemove: () => void;
}) {
  const set = (k: keyof ResumeEducation, v: string) => onChange({ ...edu, [k]: v });
  return (
    <div className="rounded-xl border border-rule bg-paper p-4">
      <div className="mb-3 grid gap-2 md:grid-cols-2">
        <Field label="School" value={edu.school} onChange={(v) => set("school", v)} placeholder="University" />
        <Field label="Degree" value={edu.degree} onChange={(v) => set("degree", v)} placeholder="B.A. Field" />
        <Field label="Start" value={edu.start} onChange={(v) => set("start", v)} placeholder="2014" />
        <Field label="End" value={edu.end} onChange={(v) => set("end", v)} placeholder="2018" />
      </div>
      <Textarea
        value={edu.notes ?? ""}
        onChange={(v) => set("notes", v)}
        placeholder="Honors, coursework, GPA — optional."
        rows={2}
      />
      <div className="mt-3 flex justify-end">
        <button onClick={onRemove} className="text-xs text-ink-mute transition-colors hover:text-amber-deep">
          Remove
        </button>
      </div>
    </div>
  );
}

function SkillsEditor({ value, onChange }: { value: string[]; onChange: (v: string[]) => void }) {
  const [draft, setDraft] = useState("");

  function commit() {
    const t = draft.trim();
    if (!t) return;
    if (value.includes(t)) {
      setDraft("");
      return;
    }
    onChange([...value, t]);
    setDraft("");
  }

  return (
    <div>
      <div className="mb-2 flex flex-wrap gap-2">
        {value.map((s) => (
          <span
            key={s}
            className="inline-flex items-center gap-1 rounded-full border border-rule bg-paper px-3 py-1 text-[13px]"
          >
            {s}
            <button
              onClick={() => onChange(value.filter((x) => x !== s))}
              aria-label={`Remove ${s}`}
              className="text-ink-mute hover:text-amber-deep"
            >
              ✕
            </button>
          </span>
        ))}
      </div>
      <div className="flex gap-2">
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === ",") {
              e.preventDefault();
              commit();
            }
          }}
          placeholder="Add a skill, hit Enter…"
          className="flex-1 rounded-md border border-rule bg-paper px-3 py-2 text-[14px] outline-none focus:border-ink"
        />
        <button onClick={commit} className="rounded-full bg-ink px-4 py-2 text-xs text-cream hover:bg-amber">
          Add
        </button>
      </div>
    </div>
  );
}

function TemplateSwitcher({ value, onChange }: { value: string; onChange: (id: string) => void }) {
  return (
    <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
      {templates.map((t) => (
        <button
          key={t.id}
          onClick={() => onChange(t.id)}
          className={`group rounded-lg border p-3 text-left transition-all hover:-translate-y-0.5 ${
            value === t.id ? "border-ink bg-paper shadow-soft" : "border-rule bg-paper hover:border-ink"
          }`}
        >
          <div className="font-serif text-[15px] font-medium tracking-tightish">{t.name}</div>
          <div className="font-mono text-[10px] uppercase tracking-[0.14em] text-ink-mute">{t.tag}</div>
        </button>
      ))}
    </div>
  );
}

/* ────────────────────────── Helpers ────────────────────────── */

function newId(): string {
  return Math.random().toString(36).slice(2, 10);
}
function newExperience(): ResumeExperience {
  return {
    id: newId(),
    company: "",
    role: "",
    location: "",
    start: "",
    end: "",
    bullets: [""],
  };
}
function newEducation(): ResumeEducation {
  return {
    id: newId(),
    school: "",
    degree: "",
    start: "",
    end: "",
    notes: "",
  };
}
