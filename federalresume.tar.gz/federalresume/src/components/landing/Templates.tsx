import Link from "next/link";
import { Reveal } from "./Reveal";

export function Templates() {
  return (
    <section id="templates" className="relative z-10 px-[clamp(20px,4vw,56px)] py-[clamp(70px,9vw,110px)]">
      <div className="mx-auto max-w-[1240px]">
        <div className="mb-[50px] text-center">
          <Reveal as="h2" className="mb-[14px] font-serif text-[clamp(36px,5vw,56px)] font-normal leading-[1.05] tracking-tighter2">
            Templates designed by
            <br />
            people who <em className="font-serif italic text-amber">read</em>.
          </Reveal>
          <Reveal as="p" delay={1} className="mx-auto max-w-[540px] text-[16px] text-ink-soft">
            No &ldquo;creative&rdquo; templates with cartoon icons. Each one is typeset like it belongs in a literary
            magazine, not a clip-art folder.
          </Reveal>
        </div>

        <div className="mb-[30px] grid grid-cols-2 gap-[22px] md:grid-cols-4">
          <TemplateCard delay={0} name="Broadsheet" tag="Classic">
            <ClassicMini />
          </TemplateCard>
          <TemplateCard delay={1} name="Sidebar" tag="Modern">
            <ModernMini />
          </TemplateCard>
          <TemplateCard delay={2} name="Editorial" tag="Serif">
            <EditorialMini />
          </TemplateCard>
          <TemplateCard delay={3} name="Whisper" tag="Minimal">
            <MinimalMini />
          </TemplateCard>
        </div>

        <Reveal className="flex justify-center">
          <Link
            href="/auth/signup"
            className="group inline-flex items-center gap-[6px] border-b border-amber pb-[2px] font-serif text-[17px] italic text-amber transition-all hover:gap-3"
          >
            View all 18 templates →
          </Link>
        </Reveal>
      </div>
    </section>
  );
}

function TemplateCard({
  name,
  tag,
  delay,
  children,
}: {
  name: string;
  tag: string;
  delay: 0 | 1 | 2 | 3;
  children: React.ReactNode;
}) {
  return (
    <Reveal delay={delay} className="cursor-pointer transition-transform hover:-translate-y-1.5">
      <div className="relative aspect-[8.5/11] overflow-hidden rounded-lg border border-rule bg-paper p-[18px_14px] text-[8px] shadow-soft transition-shadow group-hover:shadow-lg">
        {children}
      </div>
      <div className="mt-[14px] flex flex-col gap-2">
        <div className="flex items-baseline justify-between">
          <span className="font-serif text-[17px] font-medium tracking-[-0.01em]">{name}</span>
          <span className="font-mono text-[10px] uppercase tracking-[0.12em] text-ink-mute">{tag}</span>
        </div>
        <div className="flex gap-[5px]">
          {["#1B1916", "#C44A1A", "#3D5240", "#A86B3D", "#5B6A82", "#8E3320"].map((c, i) => (
            <span
              key={c}
              style={{ background: c, outline: i === 0 ? "1px solid var(--ink)" : undefined, outlineOffset: 2 }}
              className="block h-3 w-3 rounded-full border border-rule transition-transform hover:scale-110"
            />
          ))}
        </div>
      </div>
    </Reveal>
  );
}

function ClassicMini() {
  return (
    <div>
      <div className="mb-[1px] font-serif text-[14px] font-medium">Maya Hernandez</div>
      <div className="mb-2 font-mono text-[6.5px] uppercase tracking-[0.06em] text-ink-mute">Senior Product Designer</div>
      <div className="mb-2 h-px bg-ink" />
      <div className="mb-1 font-mono text-[6px] uppercase tracking-[0.16em] text-amber">Summary</div>
      <Bars n={3} />
      <div className="mb-1 mt-2 font-mono text-[6px] uppercase tracking-[0.16em] text-amber">Experience</div>
      <Bars n={4} />
      <div className="mb-1 mt-2 font-mono text-[6px] uppercase tracking-[0.16em] text-amber">Education</div>
      <Bars n={1} />
    </div>
  );
}

function ModernMini() {
  return (
    <div className="relative -m-[18px_14px] h-full">
      <div className="absolute left-0 top-0 h-full w-[35%] bg-amber" />
      <div className="relative ml-[40%] bg-ink p-[18px_14px] text-paper" style={{ minHeight: "100%" }}>
        <div className="mb-[2px] font-serif text-[13px] font-semibold">Maya Hernandez</div>
        <div className="mb-2 font-mono text-[6px] uppercase tracking-[0.06em] opacity-70">Senior Product Designer</div>
        <BarsLight n={5} />
      </div>
    </div>
  );
}

function EditorialMini() {
  return (
    <div className="bg-cream-2 -m-[18px_14px] h-full p-[18px_14px]">
      <div className="font-serif text-[22px] font-normal leading-none tracking-[-0.03em]">
        <span className="italic">
          Maya
          <br />
          Hernandez
        </span>
      </div>
      <div className="mb-[10px] mt-1.5 font-mono text-[6px] uppercase tracking-[0.16em] text-amber">
        Senior Product Designer
      </div>
      <div className="grid grid-cols-[1fr_1.3fr] gap-[6px]">
        <div>
          <div className="mb-1 font-mono text-[5.5px] font-medium uppercase tracking-[0.18em] text-ink">Contact</div>
          <Bars n={2} />
          <div className="mb-1 mt-2 font-mono text-[5.5px] font-medium uppercase tracking-[0.18em] text-ink">Skills</div>
          <Bars n={3} />
        </div>
        <div>
          <div className="mb-1 font-mono text-[5.5px] font-medium uppercase tracking-[0.18em] text-ink">Experience</div>
          <Bars n={4} />
        </div>
      </div>
    </div>
  );
}

function MinimalMini() {
  return (
    <div>
      <div className="mb-[1px] text-[12px] font-medium tracking-[-0.01em]">maya hernandez.</div>
      <div className="mb-[16px] text-[6px] text-ink-mute">senior product designer</div>
      <div className="mb-1 mt-2 text-[7px] font-medium text-ink">work</div>
      <Bars n={3} thinner />
      <div className="mb-1 mt-2 text-[7px] font-medium text-ink">education</div>
      <Bars n={2} thinner />
      <div className="mb-1 mt-2 text-[7px] font-medium text-ink">tools</div>
      <Bars n={1} thinner />
    </div>
  );
}

function Bars({ n, thinner }: { n: number; thinner?: boolean }) {
  return (
    <>
      {Array.from({ length: n }).map((_, i) => (
        <div
          key={i}
          className={`mb-[3px] rounded-[1px] bg-cream-2 ${thinner ? "h-[2.5px]" : "h-[3px]"}`}
          style={{ width: i % 3 === 1 ? "85%" : i % 3 === 2 ? "60%" : "100%" }}
        />
      ))}
    </>
  );
}

function BarsLight({ n }: { n: number }) {
  return (
    <>
      {Array.from({ length: n }).map((_, i) => (
        <div
          key={i}
          className="mb-[3px] h-[3px] rounded-[1px]"
          style={{
            background: "rgba(255,255,255,.2)",
            width: i % 3 === 1 ? "80%" : i % 3 === 2 ? "60%" : "100%",
          }}
        />
      ))}
    </>
  );
}
