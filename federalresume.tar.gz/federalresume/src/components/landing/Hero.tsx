import Link from "next/link";
import { Reveal } from "./Reveal";

export function Hero() {
  return (
    <section className="px-[clamp(20px,4vw,56px)] pb-[clamp(60px,8vw,100px)] pt-[clamp(50px,7vw,90px)]">
      <div className="relative z-10 mx-auto max-w-[1240px] text-center">
        <Reveal as="div" immediate className="mb-[26px] inline-flex items-center gap-[10px] font-mono text-[12px] uppercase tracking-[0.14em] text-ink-mute before:inline-block before:h-px before:w-[24px] before:bg-ink-mute after:inline-block after:h-px after:w-[24px] after:bg-ink-mute">
          FederalResume · The career &amp; document studio
        </Reveal>

        <Reveal as="h1" delay={1} immediate className="mx-auto mb-[24px] max-w-[880px] font-serif text-[clamp(44px,6.5vw,84px)] font-normal leading-[0.98] tracking-[-0.035em]">
          Job-winning <em className="font-serif italic text-amber">résumé</em>
          <br />
          builder.
        </Reveal>

        <Reveal as="p" delay={2} immediate className="mx-auto mb-[36px] max-w-[560px] text-[17px] leading-[1.55] text-ink-soft">
          Get hired 2× as fast.
          <sup className="align-super text-[10px] font-semibold text-amber">1</sup> Choose from typeset,
          recruiter-approved templates. Add ready-to-use bullet points and phrases written by people who actually
          read résumés.
        </Reveal>

        <Reveal as="div" delay={3} immediate className="mb-[56px] flex flex-wrap justify-center gap-[12px]">
          <Link
            href="/auth/signup"
            className="btn-amber inline-flex items-center gap-2 rounded-full bg-amber px-[26px] py-[14px] text-[14.5px] font-medium text-paper transition-all hover:-translate-y-[1px] hover:bg-amber-deep hover:shadow-[0_8px_24px_-8px_rgba(196,74,26,.5)]"
          >
            Create new résumé
          </Link>
          <Link
            href="/auth/login"
            className="inline-flex items-center gap-2 rounded-full border border-ink px-[26px] py-[14px] text-[14.5px] font-medium text-ink transition-colors hover:bg-ink hover:text-cream"
          >
            Optimise my résumé
          </Link>
        </Reveal>

        <div className="relative mx-auto grid max-w-[1100px] grid-cols-1 gap-[18px] text-left md:grid-cols-3">
          <StepCard
            n={1}
            tag="Step 01 · Pick"
            dotClass="bg-ink"
            title={
              <>
                A <em className="font-serif italic text-amber">typeset</em> template, not clip art.
              </>
            }
            mock={<TemplateMock />}
          />
          <StepCard
            n={2}
            delay={1}
            tag="Step 02 · Polish"
            dotClass="bg-amber"
            title={
              <>
                Generate content with <em className="font-serif italic text-amber">AI support</em>.
              </>
            }
            mock={<AiMock />}
          />
          <StepCard
            n={3}
            delay={2}
            tag="Step 03 · Apply"
            dotClass="bg-moss"
            title={
              <>
                Get your résumé &amp; <em className="font-serif italic text-amber">apply</em>.
              </>
            }
            mock={<FinalMock />}
          />
        </div>
      </div>
    </section>
  );
}

function StepCard({
  tag,
  title,
  mock,
  dotClass,
  delay = 0,
}: {
  n: number;
  tag: string;
  title: React.ReactNode;
  mock: React.ReactNode;
  dotClass: string;
  delay?: 0 | 1 | 2;
}) {
  return (
    <Reveal delay={delay} className="group relative overflow-hidden rounded-[14px] border border-rule bg-paper px-[22px] pb-px pt-[22px] transition-all hover:-translate-y-1 hover:border-ink hover:shadow-soft">
      <div className="mb-[14px] flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.14em] text-ink-mute">
        <span className={`inline-block h-2 w-2 rounded-full ${dotClass}`} />
        {tag}
      </div>
      <div className="mb-[18px] min-h-[50px] font-serif text-[22px] font-medium leading-[1.15] tracking-tightish">
        {title}
      </div>
      <div className="relative -mx-[22px] -mb-px h-[200px] overflow-hidden border-t border-rule bg-cream-2">
        {mock}
      </div>
    </Reveal>
  );
}

function TemplateMock() {
  return (
    <>
      <div className="absolute left-1/2 top-[18px] aspect-[8.5/11] w-[150px] -translate-x-1/2 rounded-[4px] bg-white p-[14px_12px] shadow-lg">
        <div className="font-serif text-[11px] font-semibold tracking-[-0.01em]">Maya Hernandez</div>
        <div className="mb-[7px] mt-[1px] font-mono text-[6.5px] uppercase tracking-[0.06em] text-ink-mute">
          Senior Product Designer
        </div>
        <div className="mb-[6px] h-px bg-ink" />
        <div className="my-[5px] mb-[3px] mt-[5px] font-mono text-[5px] font-medium uppercase tracking-[0.18em] text-amber">
          Summary
        </div>
        <Lines />
        <div className="my-[5px] mb-[3px] mt-[5px] font-mono text-[5px] font-medium uppercase tracking-[0.18em] text-amber">
          Experience
        </div>
        <Lines extra />
      </div>
      <div className="absolute bottom-[18px] right-[14px] rounded-[4px] bg-ink px-2 py-1 font-mono text-[9px] font-medium uppercase tracking-[0.1em] text-paper">
        Recruiter-approved
      </div>
    </>
  );
}

function Lines({ extra = false }: { extra?: boolean }) {
  return (
    <>
      <div className="mb-[2.5px] h-[2px] w-[85%] rounded-[1px] bg-cream-2" />
      <div className="mb-[2.5px] h-[2px] rounded-[1px] bg-cream-2" />
      <div className="mb-[2.5px] h-[2px] w-[60%] rounded-[1px] bg-cream-2" />
      {extra && <div className="mb-[2.5px] h-[2px] rounded-[1px] bg-cream-2" />}
    </>
  );
}

function AiMock() {
  return (
    <div className="absolute inset-[18px_14px] flex flex-col gap-2 overflow-hidden rounded-lg border border-rule bg-paper p-[14px] text-[11px]">
      <div className="font-mono text-[9px] font-medium uppercase tracking-[0.14em] text-amber before:content-['✦_']">
        AI suggestions
      </div>
      <div className="font-serif text-[11px] leading-[1.4] text-ink-soft">
        Cultivated strong business relationships with customers to drive new development.
      </div>
      <div
        className="relative rounded-md border border-amber p-[8px_10px] font-serif text-[11px] italic leading-[1.4] text-ink"
        style={{ background: "var(--amber-soft, rgba(196,74,26,0.10))" }}
      >
        <span className="absolute right-2 top-2 text-[10px] text-amber">✦</span>
        Built and nurtured a portfolio of 40+ enterprise relationships, driving $2.1M in new pipeline.
      </div>
      <div className="h-1 w-[30%] animate-pulse rounded-[2px] bg-amber" />
    </div>
  );
}

function FinalMock() {
  return (
    <>
      <div
        className="absolute left-1/2 top-[14px] aspect-[8.5/11] w-[130px] -translate-x-1/2 rounded-[4px] bg-white p-[12px_10px] shadow-lg"
        style={{ transform: "translateX(-50%) rotate(-3deg)" }}
      >
        <div className="font-serif text-[10px] font-semibold">Maya Hernandez</div>
        <div className="mb-[6px] font-mono text-[5.5px] uppercase tracking-[0.06em] text-ink-mute">
          Senior Product Designer
        </div>
        <div className="mb-[5px] h-px bg-ink" />
        <div className="mb-[2px] mt-1 font-mono text-[4px] font-medium uppercase tracking-[0.18em] text-moss">
          Summary
        </div>
        <div className="mb-[2px] h-[1.5px] rounded-[1px] bg-cream-2" />
        <div className="mb-[2px] h-[1.5px] w-[60%] rounded-[1px] bg-cream-2" />
        <div className="mb-[2px] mt-1 font-mono text-[4px] font-medium uppercase tracking-[0.18em] text-moss">
          Experience
        </div>
        <div className="mb-[2px] h-[1.5px] rounded-[1px] bg-cream-2" />
        <div className="mb-[2px] h-[1.5px] rounded-[1px] bg-cream-2" />
        <div className="mb-[2px] h-[1.5px] w-[60%] rounded-[1px] bg-cream-2" />
        <div className="mb-[2px] h-[1.5px] rounded-[1px] bg-cream-2" />
      </div>
      <div className="absolute bottom-[26px] right-[18px] flex animate-[bob_3s_ease-in-out_infinite] items-center gap-[5px] rounded-full bg-moss px-[10px] py-[5px] font-mono text-[9px] font-medium uppercase tracking-[0.1em] text-paper">
        ↓ PDF ready
      </div>
      <style>{`
        @keyframes bob {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-3px); }
        }
      `}</style>
    </>
  );
}
