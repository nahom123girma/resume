export function TrustBar() {
  const logos = ["amazon", "Pinterest", "NIKE", "Walmart", "SEPHORA"];

  return (
    <section className="relative z-10 border-y border-rule bg-cream-2 py-6">
      <div className="mx-auto flex max-w-[1240px] flex-wrap items-center justify-between gap-10 px-[clamp(20px,4vw,56px)]">
        <div className="flex items-center gap-3 text-[13px] text-ink-soft">
          <span className="font-mono text-[11px] font-medium uppercase tracking-[0.14em] text-ink">
            Excellent
          </span>
          <span className="text-[16px] text-amber" aria-label="5 out of 5 stars">
            ★ ★ ★ ★ ★
          </span>
          <span>
            <em className="font-serif italic text-ink">4.7 / 5</em> from 24,318 reviews
          </span>
        </div>
        <div className="flex flex-wrap items-center gap-[30px] text-[13px] text-ink-mute">
          <span className="font-serif text-[14px] italic">Customers have been hired by</span>
          <div className="flex flex-wrap items-center gap-[26px] font-serif text-[17px] font-medium tracking-[-0.01em] text-ink-soft">
            {logos.map((l) => (
              <span key={l} className="opacity-75 transition-opacity hover:text-ink hover:opacity-100">
                {l}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
