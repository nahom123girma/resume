"use client";

import { ReactNode, useEffect, useRef } from "react";

type Props = {
  children: ReactNode;
  delay?: 0 | 1 | 2 | 3;
  className?: string;
  immediate?: boolean;
  as?: keyof JSX.IntrinsicElements;
};

export function Reveal({ children, delay = 0, className = "", immediate = false, as = "div" }: Props) {
  const ref = useRef<HTMLElement | null>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (immediate) {
      el.classList.add("in");
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            (e.target as HTMLElement).classList.add("in");
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [immediate]);

  const Tag = as as keyof JSX.IntrinsicElements;
  const delayStyle = delay ? { transitionDelay: `${delay * 0.08}s` } : undefined;
  const refSetter = (n: HTMLElement | null) => {
    ref.current = n;
  };

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return (
    // @ts-expect-error generic ref typing
    <Tag ref={refSetter} style={delayStyle} className={`reveal ${className}`}>
      {children}
    </Tag>
  );
}
