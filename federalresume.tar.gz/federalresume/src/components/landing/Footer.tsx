import Link from "next/link";

export function Footer() {
  return (
    <footer className="relative z-10 border-t border-rule bg-cream-2 px-[clamp(20px,4vw,56px)] pb-8 pt-[50px] text-sm">
      <div className="mx-auto max-w-[1240px]">
        <div className="mb-10 grid gap-[50px] md:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <Link href="/" className="flex items-baseline gap-[6px] font-serif text-[26px] font-semibold tracking-[-0.02em]">
              FederalResume
              <span className="ml-[2px] inline-block h-[7px] w-[7px] self-center rounded-full bg-amber" />
            </Link>
            <p className="mt-[14px] max-w-[280px] font-serif text-[16px] italic leading-[1.45] text-ink-soft">
              &ldquo;The career and document studio for people who give a damn about how their work looks.&rdquo;
            </p>
          </div>

          <FootCol title="Product" links={["Resume Builder", "Cover Letters", "PDF Tools", "Job Search", "Application Tracker"]} />
          <FootCol title="Tools" links={["PDF to Word", "Word to PDF", "Merge PDF", "Compress PDF", "OCR Scanner"]} />
          <FootCol title="Company" links={["About", "Blog", "Careers", "Privacy", "Terms"]} />
        </div>
        <div className="flex flex-wrap items-center justify-between gap-[14px] border-t border-rule pt-6 text-[13px] text-ink-mute">
          <span>© 2026 FederalResume Inc. Designed in Brooklyn. Typeset everywhere.</span>
          <span className="font-mono">v1.0 · Last shipped 2 days ago</span>
        </div>
      </div>
    </footer>
  );
}

function FootCol({ title, links }: { title: string; links: string[] }) {
  return (
    <div>
      <h5 className="mb-4 font-mono text-[11px] font-medium uppercase tracking-[0.16em] text-ink-mute">{title}</h5>
      <ul className="flex flex-col gap-[9px]">
        {links.map((l) => (
          <li key={l}>
            <a href="#" className="text-ink-soft transition-colors hover:text-amber">
              {l}
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
}
