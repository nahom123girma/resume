import { Reveal } from "./Reveal";

export function Features() {
  return (
    <section id="features" className="relative z-10 px-[clamp(20px,4vw,56px)] py-[clamp(70px,9vw,110px)]">
      <div className="mx-auto max-w-[1240px]">
        <div className="mb-[50px] text-center">
          <Reveal as="h2" className="mb-[14px] font-serif text-[clamp(36px,5vw,56px)] font-normal leading-[1.05] tracking-tighter2">
            Six features to <em className="italic text-amber">boost</em>
            <br />
            your job search.
          </Reveal>
          <Reveal as="p" delay={1} className="mx-auto max-w-[540px] text-[16px] text-ink-soft">
            Each one designed to do one thing exceptionally — and quietly hand you off to the next.
          </Reveal>
        </div>

        <div className="grid grid-cols-1 gap-[22px] md:grid-cols-2 lg:grid-cols-3">
          <FeatureCard
            num="№ 01"
            title={<>Template <em className="italic text-amber">Library</em></>}
            blurb="Eighteen typeset templates. Each tested across four ATS engines before it ships."
          >
            <TemplatesMock />
          </FeatureCard>

          <FeatureCard
            delay={1}
            num="№ 02"
            title={<>Enhance with <em className="italic text-amber">AI</em></>}
            blurb="Paste a job duty, get three quantified rewrites that don&rsquo;t sound like AI."
          >
            <AIMock />
          </FeatureCard>

          <FeatureCard
            delay={2}
            num="№ 03"
            title={<>Résumé <em className="italic text-amber">Review</em></>}
            blurb="The same parsers recruiters use — pointed at your draft, not against it."
          >
            <ReviewMock />
          </FeatureCard>

          <FeatureCard
            num="№ 04"
            title={<>Cover <em className="italic text-amber">Letter</em> Studio</>}
            blurb="One click per job description. Personalised, in your voice, never sludgy."
          >
            <LetterMock />
          </FeatureCard>

          <FeatureCard
            delay={1}
            num="№ 05"
            title={<>Personal <em className="italic text-amber">Page</em></>}
            blurb={
              <>
                A one-page portfolio at <span className="font-mono text-amber">federalresume.com/you</span> for the recruiters who Google.
              </>
            }
          >
            <WebsiteMock />
          </FeatureCard>

          <FeatureCard
            delay={2}
            num="№ 06"
            title={<>Application <em className="italic text-amber">Tracker</em></>}
            blurb="Every résumé you sent, every reply you got, every callback waiting."
          >
            <TrackMock />
          </FeatureCard>
        </div>
      </div>
    </section>
  );
}

function FeatureCard({
  num,
  title,
  blurb,
  children,
  delay = 0,
}: {
  num: string;
  title: React.ReactNode;
  blurb: React.ReactNode;
  children: React.ReactNode;
  delay?: 0 | 1 | 2;
}) {
  return (
    <Reveal delay={delay} className="group relative cursor-pointer overflow-hidden rounded-[14px] border border-rule bg-paper px-[26px] pb-px pt-[26px] transition-all hover:-translate-y-1 hover:border-ink hover:shadow-soft">
      <div className="mb-[12px] font-mono text-[11px] uppercase tracking-[0.14em] text-ink-mute">{num}</div>
      <h3 className="mb-2 font-serif text-[22px] font-medium leading-[1.15] tracking-tightish">{title}</h3>
      <p className="mb-[22px] text-[13.5px] leading-[1.5] text-ink-soft">{blurb}</p>
      <div className="relative -mx-[26px] h-[150px] overflow-hidden border-t border-rule bg-cream-2">{children}</div>
    </Reveal>
  );
}

function TemplatesMock() {
  return (
    <div className="flex justify-center gap-2 pt-4">
      {[-6, 0, 6].map((rot, i) => (
        <div
          key={i}
          className="aspect-[8.5/11] w-[60px] rounded-[3px] bg-white p-[6px_5px] shadow-soft"
          style={{ transform: `rotate(${rot}deg)` }}
        >
          <div className="mb-1 font-serif text-[5.5px] font-semibold">{["Avery", "Maya", "Jordan"][i]}</div>
          <div className="mb-[1.5px] h-[1.5px] w-[60%] rounded-[1px] bg-cream-2" />
          <div className="mb-[1.5px] h-[1.5px] rounded-[1px] bg-cream-2" />
          <div className="mb-[1.5px] h-[1.5px] rounded-[1px] bg-cream-2" />
          <div className="mb-[1.5px] h-[1.5px] w-[60%] rounded-[1px] bg-cream-2" />
        </div>
      ))}
    </div>
  );
}

function AIMock() {
  const rows = [
    { state: "done", text: "Reviewed grammar" },
    { state: "active", text: "Sharpening bullet 3" },
    { state: "off", text: "Match to JD keywords" },
    { state: "off", text: "Tone consistency" },
  ] as const;
  return (
    <div className="flex h-full flex-col gap-[7px] p-[14px_18px]">
      {rows.map((r) => (
        <div
          key={r.text}
          className={`flex items-center gap-2 rounded-md border px-[10px] py-[6px] font-serif text-[11px] ${
            r.state === "active"
              ? "border-amber text-ink"
              : r.state === "done"
                ? "border-rule text-moss"
                : "border-rule text-ink-soft"
          } bg-paper`}
        >
          <span className={r.state === "done" ? "font-semibold text-moss" : r.state === "active" ? "text-amber" : "text-ink-mute"}>
            {r.state === "done" ? "✓" : r.state === "active" ? "✦" : "○"}
          </span>
          {r.text}
        </div>
      ))}
    </div>
  );
}

function ReviewMock() {
  return (
    <div className="grid h-full grid-cols-[1fr_auto] items-center gap-[14px] p-[14px]">
      <div className="font-serif text-[56px] font-medium leading-[0.9] tracking-[-0.04em]">
        87<span className="text-amber">%</span>
      </div>
      <div className="font-mono text-[10px] uppercase tracking-[0.1em] text-ink-mute">
        <div className="mb-[5px]">Format <strong className="font-medium text-moss">Clean</strong></div>
        <div className="mb-[5px]">Length <strong className="font-medium text-moss">1 page</strong></div>
        <div className="mb-[5px]">Keywords <strong className="font-medium text-moss">12/14</strong></div>
      </div>
    </div>
  );
}

function LetterMock() {
  return (
    <div className="grid h-full place-items-center p-[16px]">
      <div className="w-[90%] max-w-[200px] -rotate-[1.5deg] rounded-[4px] border border-rule bg-white p-[14px_16px] font-serif text-[9px] italic leading-[1.5] text-ink-soft shadow-soft">
        <div className="mb-1.5">Dear hiring manager,</div>
        <div className="mb-[2px] h-[1.5px] rounded-[1px] bg-cream-2" />
        <div className="mb-[2px] h-[1.5px] w-[60%] rounded-[1px] bg-cream-2" />
        <div className="mb-[2px] h-[1.5px] rounded-[1px] bg-cream-2" />
        <div className="mb-[2px] h-[1.5px] rounded-[1px] bg-cream-2" />
        <div className="mb-[2px] h-[1.5px] w-[60%] rounded-[1px] bg-cream-2" />
        <div className="mt-1.5 font-hand text-[16px] not-italic tracking-[0.04em] text-ink">— Maya</div>
      </div>
    </div>
  );
}

function WebsiteMock() {
  return (
    <div className="h-full p-[14px_18px]">
      <div className="h-full overflow-hidden rounded-md border border-rule bg-paper">
        <div className="flex items-center gap-1 border-b border-rule bg-cream-2 px-2 py-[5px]">
          <div className="h-[6px] w-[6px] rounded-full bg-rule" />
          <div className="h-[6px] w-[6px] rounded-full bg-rule" />
          <div className="h-[6px] w-[6px] rounded-full bg-rule" />
          <div className="ml-[6px] flex-1 rounded-[3px] bg-paper px-[6px] py-[2px] font-mono text-[8px] text-ink-mute">
            federalresume.com/maya
          </div>
        </div>
        <div className="p-[10px_14px] font-serif">
          <div className="text-[14px] font-medium">Maya Hernandez</div>
          <div className="mb-[6px] text-[8.5px] italic text-ink-mute">Senior Product Designer · SF</div>
          <div className="mb-[2px] h-[1.5px] rounded-[1px] bg-cream-2" />
          <div className="mb-[2px] h-[1.5px] w-[60%] rounded-[1px] bg-cream-2" />
          <div className="mb-[2px] h-[1.5px] rounded-[1px] bg-cream-2" />
        </div>
      </div>
    </div>
  );
}

function TrackMock() {
  const bars = [
    { h: 30, label: "S", amber: false },
    { h: 55, label: "A", amber: false },
    { h: 75, label: "I", amber: true },
    { h: 25, label: "O", amber: false },
    { h: 45, label: "R", amber: false },
  ];
  return (
    <div className="flex h-full items-end gap-[5px] p-[14px_14px_28px]">
      {bars.map((b) => (
        <div
          key={b.label}
          className={`relative flex-1 rounded-t-[2px] ${b.amber ? "bg-amber" : "bg-ink"}`}
          style={{ height: `${b.h}%` }}
        >
          <span className="absolute -bottom-4 left-1/2 -translate-x-1/2 font-mono text-[8px] tracking-[0.05em] text-ink-mute">
            {b.label}
          </span>
        </div>
      ))}
    </div>
  );
}
