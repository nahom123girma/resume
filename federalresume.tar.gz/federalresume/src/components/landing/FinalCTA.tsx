import Link from "next/link";
import { Reveal } from "./Reveal";

export function FinalCTA() {
  return (
    <section className="relative z-10 border-t border-rule px-[clamp(20px,4vw,56px)] py-[clamp(60px,8vw,100px)] pb-[clamp(70px,10vw,130px)] text-center">
      <div className="mx-auto max-w-[1240px]">
        <Reveal as="h2" className="mb-[20px] font-serif text-[clamp(40px,6vw,80px)] font-normal leading-[0.95] tracking-[-0.035em]">
          Stop tweaking.
          <br />
          <em className="italic text-amber">Start applying.</em>
        </Reveal>
        <Reveal as="p" delay={1} className="mx-auto mb-9 max-w-[520px] text-[17px] text-ink-soft">
          Free forever for the basics. Seven days free for everything. The job you want already posted twenty
          minutes ago.
        </Reveal>
        <Reveal delay={2} className="flex flex-wrap justify-center gap-3">
          <Link
            href="/auth/signup"
            className="inline-flex items-center gap-2 rounded-full bg-amber px-[26px] py-[14px] text-[14.5px] font-medium text-paper transition-all hover:-translate-y-px hover:bg-amber-deep hover:shadow-[0_8px_24px_-8px_rgba(196,74,26,.5)]"
          >
            Create new résumé
          </Link>
          <Link
            href="/auth/login"
            className="inline-flex items-center gap-2 rounded-full border border-ink px-[26px] py-[14px] text-[14.5px] font-medium text-ink transition-colors hover:bg-ink hover:text-cream"
          >
            Optimise my résumé
          </Link>
        </Reveal>
      </div>
    </section>
  );
}
