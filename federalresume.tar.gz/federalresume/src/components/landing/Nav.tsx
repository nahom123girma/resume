"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

export function Nav() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      className={`sticky top-0 z-50 backdrop-blur-md transition-colors ${
        scrolled ? "border-b border-rule" : "border-b border-transparent"
      }`}
      style={{ background: "color-mix(in oklab, var(--cream) 78%, transparent)" }}
    >
      <div className="relative z-10 mx-auto flex max-w-[1240px] items-center justify-between px-[clamp(20px,4vw,56px)] py-[18px]">
        <Link href="/" className="flex items-baseline gap-[6px] font-serif text-[26px] font-semibold tracking-[-0.02em]">
          FederalResume
          <span className="ml-[2px] inline-block h-[7px] w-[7px] self-center rounded-full bg-amber" />
        </Link>

        <div className="hidden gap-[30px] text-sm text-ink-soft md:flex">
          <a href="#templates" className="nav-link">Templates</a>
          <a href="#features" className="nav-link">Features</a>
          <a href="#" className="nav-link">PDF Tools</a>
          <a href="#" className="nav-link">Job Search</a>
          <a href="#" className="nav-link">Pricing</a>
        </div>

        <div className="flex items-center gap-[14px]">
          <Link href="/auth/login" className="hidden text-sm text-ink-soft hover:text-ink md:inline">
            Log in
          </Link>
          <Link
            href="/auth/signup"
            className="inline-flex items-center gap-2 whitespace-nowrap rounded-full border border-transparent bg-ink px-[22px] py-[11px] text-sm font-medium text-cream transition-all hover:-translate-y-[1px] hover:bg-amber hover:shadow-[0_8px_24px_-8px_rgba(196,74,26,.5)]"
          >
            Get started
          </Link>
        </div>
      </div>

      <style jsx>{`
        .nav-link {
          position: relative;
          padding: 4px 0;
          transition: color 0.2s;
        }
        .nav-link:hover {
          color: var(--ink);
        }
        .nav-link::after {
          content: "";
          position: absolute;
          left: 0;
          right: 100%;
          bottom: 0;
          height: 1px;
          background: var(--ink);
          transition: right 0.3s ease;
        }
        .nav-link:hover::after {
          right: 0;
        }
      `}</style>
    </nav>
  );
}
