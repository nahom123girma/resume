"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

export function FloatingCTA() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 800);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <Link
      href="/auth/signup"
      aria-hidden={!visible}
      className={`fixed bottom-6 right-6 z-40 inline-flex items-center gap-2 rounded-full bg-ink px-5 py-3 text-sm font-medium text-cream shadow-lg transition-all ${
        visible ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-4 opacity-0"
      } hover:bg-amber hover:shadow-[0_8px_24px_-8px_rgba(196,74,26,.5)]`}
    >
      <span aria-hidden>✦</span> Start building
    </Link>
  );
}
