import Link from "next/link";
import { Reveal } from "./Reveal";

export function Results() {
  return (
    <section className="relative z-10 border-y border-rule bg-paper-2 px-[clamp(20px,4vw,56px)] py-[clamp(70px,9vw,110px)]">
      <div className="mx-auto max-w-[1240px]">
        <div className="relative mb-[60px] grid items-center gap-[30px] md:grid-cols-[1fr_auto]">
          <Reveal as="h2" className="max-w-[580px] font-serif text-[clamp(36px,5.5vw,64px)] font-normal leading-none tracking-[-0.03em]">
            Create a résumé
            <br />
            that gets <span className="scribble">results</span>.
          </Reveal>

          <Reveal delay={1} className="relative flex items-center gap-6">
            <svg viewBox="0 0 110 60" className="hidden h-[60px] w-[110px] -translate-y-3 text-ink md:block">
              <path d="M5 30 Q 35 8, 70 22 T 100 38" stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinecap="round" />
              <path d="M93 33 L100 38 L96 45" stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinejoin="round" strokeLinecap="round" />
            </svg>
            <Link
              href="/auth/signup"
              className="inline-flex items-center gap-2 rounded-full bg-amber px-[26px] py-[14px] text-[14.5px] font-medium text-paper transition-all hover:-translate-y-px hover:bg-amber-deep hover:shadow-[0_8px_24px_-8px_rgba(196,74,26,.5)]"
            >
              Choose a template
            </Link>
          </Reveal>
        </div>

        <div className="grid gap-10 md:grid-cols-3">
          <Benefit num="i." title="No experience necessary." delay={0}>
            Whether you&rsquo;re entering the workforce or you&rsquo;ve been at it twenty years, FederalResume&rsquo;s
            Composer gives you a starting structure that flatters either situation. No staring at a blank page.
          </Benefit>
          <Benefit num="ii." title="Tell us a bit about yourself." delay={1}>
            We&rsquo;ll suggest the bullet points, phrasing, and section ordering that hiring managers actually
            respond to — guiding you toward callbacks, not stylistic dead ends.
          </Benefit>
          <Benefit num="iii." title="Simpler than you expect." delay={2}>
            We&rsquo;ve helped over a million applicants get interviews. From first draft to final export, an
            impactful résumé starts with the right tools — and ends in your inbox.
          </Benefit>
        </div>
      </div>
    </section>
  );
}

function Benefit({ num, title, delay, children }: { num: string; title: string; delay: 0 | 1 | 2; children: React.ReactNode }) {
  return (
    <Reveal delay={delay} className="relative">
      <span className="mb-[14px] block font-serif text-[38px] italic leading-none text-amber">{num}</span>
      <h3 className="mb-[10px] font-serif text-[22px] font-medium leading-[1.15] tracking-tightish">{title}</h3>
      <p className="text-[14.5px] leading-[1.55] text-ink-soft">{children}</p>
    </Reveal>
  );
}
