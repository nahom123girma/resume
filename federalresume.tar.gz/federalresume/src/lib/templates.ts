export type TemplateDefinition = {
  id: "broadsheet" | "sidebar" | "editorial" | "whisper";
  name: string;
  tag: string;
  font: string;
  layout: "single-column" | "two-column" | "sidebar" | "minimal";
  accentColor: string;
  description: string;
};

export const templates: TemplateDefinition[] = [
  {
    id: "broadsheet",
    name: "Broadsheet",
    tag: "Classic",
    font: "Fraunces",
    layout: "single-column",
    accentColor: "#C44A1A",
    description: "Newspaper-inspired typesetting. Rules and small caps section heads.",
  },
  {
    id: "sidebar",
    name: "Sidebar",
    tag: "Modern",
    font: "Fraunces",
    layout: "sidebar",
    accentColor: "#1B1916",
    description: "Two-column with a colored rail. Strong contrast, easy scan.",
  },
  {
    id: "editorial",
    name: "Editorial",
    tag: "Serif",
    font: "Fraunces",
    layout: "two-column",
    accentColor: "#3D5240",
    description: "Italic display name, magazine-style two-column body.",
  },
  {
    id: "whisper",
    name: "Whisper",
    tag: "Minimal",
    font: "IBM Plex Sans",
    layout: "minimal",
    accentColor: "#1B1916",
    description: "Sans-serif and quiet. The résumé that doesn't shout.",
  },
];

export const accentSwatches = [
  "#1B1916",
  "#C44A1A",
  "#3D5240",
  "#A86B3D",
  "#5B6A82",
  "#8E3320",
];

export function getTemplate(id: string): TemplateDefinition {
  return templates.find((t) => t.id === id) ?? templates[0];
}
