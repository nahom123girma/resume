import type { ResumeContent } from "@/types/resume";

const FONTS_LINK = `<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;0,9..144,500;0,9..144,600;0,9..144,700;1,9..144,400&family=IBM+Plex+Sans:ital,wght@0,300;0,400;0,500;0,600;1,400&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet">`;

function escape(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

const baseCss = `
  *, *::before, *::after { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; }
  body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  ul { list-style: disc; }
  @page { size: Letter; margin: 0; }
`;

function bullets(items: string[]): string {
  if (!items.length) return "";
  return `<ul>${items.map((b) => `<li>${escape(b)}</li>`).join("")}</ul>`;
}

function broadsheet(data: ResumeContent, accent: string): string {
  const contact = [data.email, data.phone, data.location, data.website].filter(Boolean).map(escape).join("  ·  ");
  return `
  <style>
    ${baseCss}
    body { background: white; color: #1B1916; font-family: "Fraunces", Georgia, serif; font-size: 11pt; line-height: 1.45; }
    .page { padding: 56px 64px; }
    h1 { font-size: 28pt; font-weight: 600; letter-spacing: -0.02em; margin: 0; }
    .role { font-family: "IBM Plex Mono", monospace; font-size: 9pt; letter-spacing: 0.14em; text-transform: uppercase; color: ${accent}; margin-top: 4px; }
    .contact { font-family: "IBM Plex Sans", sans-serif; font-size: 9.5pt; color: #3A352D; margin-top: 6px; }
    hr { border: 0; border-top: 1px solid #1B1916; margin: 14px 0 18px; }
    h2 { font-family: "IBM Plex Mono", monospace; font-size: 9pt; letter-spacing: 0.18em; text-transform: uppercase; color: ${accent}; font-weight: 500; margin: 0 0 8px; }
    section { margin-bottom: 18px; }
    .entry { margin-bottom: 14px; }
    .entry-head { display: flex; justify-content: space-between; align-items: baseline; font-size: 11.5pt; }
    .entry-sub { font-style: italic; color: #6E6557; font-size: 10.5pt; margin-bottom: 4px; }
    .dates { font-family: "IBM Plex Mono", monospace; font-size: 9pt; letter-spacing: 0.06em; color: #6E6557; }
    ul { padding-left: 16px; margin: 4px 0 0; }
    li { margin-bottom: 3px; }
    .skills { font-size: 10.5pt; color: #3A352D; }
  </style>
  <div class="page">
    <header>
      <h1>${escape(data.name || "Your Name")}</h1>
      <div class="role">${escape(data.role || "Your Title")}</div>
      ${contact ? `<div class="contact">${contact}</div>` : ""}
    </header>
    <hr/>
    ${data.summary ? `<section><h2>Summary</h2><p>${escape(data.summary)}</p></section>` : ""}
    ${
      data.experience.length
        ? `<section><h2>Experience</h2>${data.experience
            .map(
              (e) => `<article class="entry">
              <div class="entry-head"><strong>${escape(e.role)}</strong><span class="dates">${escape(e.start)}${e.end ? " — " + escape(e.end) : ""}</span></div>
              <div class="entry-sub">${escape(e.company)}${e.location ? " · " + escape(e.location) : ""}</div>
              ${bullets(e.bullets)}
            </article>`
            )
            .join("")}</section>`
        : ""
    }
    ${
      data.education.length
        ? `<section><h2>Education</h2>${data.education
            .map(
              (e) => `<article class="entry">
              <div class="entry-head"><strong>${escape(e.school)}</strong><span class="dates">${escape(e.start)}${e.end ? " — " + escape(e.end) : ""}</span></div>
              <div class="entry-sub">${escape(e.degree)}</div>
              ${e.notes ? `<p>${escape(e.notes)}</p>` : ""}
            </article>`
            )
            .join("")}</section>`
        : ""
    }
    ${data.skills.length ? `<section><h2>Skills</h2><p class="skills">${data.skills.map(escape).join("  ·  ")}</p></section>` : ""}
  </div>`;
}

function sidebar(data: ResumeContent, accent: string): string {
  return `
  <style>
    ${baseCss}
    body { background: white; color: #1B1916; font-family: "IBM Plex Sans", sans-serif; font-size: 10.5pt; line-height: 1.45; }
    .grid { display: grid; grid-template-columns: 220px 1fr; min-height: 100vh; }
    .rail { background: ${accent}; color: #FAF6EC; padding: 48px 26px; }
    .rail-name { font-family: "Fraunces", serif; font-size: 22pt; font-weight: 600; line-height: 1.05; letter-spacing: -0.02em; margin-bottom: 4px; }
    .rail-role { font-size: 9pt; letter-spacing: 0.1em; text-transform: uppercase; opacity: 0.8; margin-bottom: 28px; }
    .rail-section { margin-bottom: 22px; font-size: 9.5pt; line-height: 1.6; }
    .rail-section h3 { font-family: "IBM Plex Mono", monospace; font-size: 8.5pt; letter-spacing: 0.18em; text-transform: uppercase; opacity: 0.85; margin: 0 0 6px; font-weight: 500; }
    .rail-edu { margin-bottom: 8px; }
    .rail-dates { font-family: "IBM Plex Mono", monospace; font-size: 8pt; opacity: 0.75; }
    .body { padding: 48px 56px; }
    .body section { margin-bottom: 22px; }
    .body h2 { font-family: "IBM Plex Mono", monospace; font-size: 9pt; letter-spacing: 0.18em; text-transform: uppercase; color: ${accent}; font-weight: 500; margin: 0 0 10px; }
    .entry { margin-bottom: 14px; }
    .entry-head { display: flex; justify-content: space-between; align-items: baseline; font-family: "Fraunces", serif; font-size: 12pt; }
    .entry-sub { font-style: italic; color: #6E6557; font-size: 10pt; }
    .dates { font-family: "IBM Plex Mono", monospace; font-size: 9pt; letter-spacing: 0.06em; color: #6E6557; }
    ul { padding-left: 16px; margin: 4px 0 0; }
    li { margin-bottom: 3px; }
  </style>
  <div class="grid">
    <aside class="rail">
      <div class="rail-name">${escape(data.name || "Your Name")}</div>
      <div class="rail-role">${escape(data.role || "Your Title")}</div>
      <div class="rail-section">
        <h3>Contact</h3>
        ${[data.email, data.phone, data.location, data.website].filter(Boolean).map((c) => `<div>${escape(c)}</div>`).join("")}
      </div>
      ${
        data.skills.length
          ? `<div class="rail-section"><h3>Skills</h3>${data.skills.map((s) => `<div>${escape(s)}</div>`).join("")}</div>`
          : ""
      }
      ${
        data.education.length
          ? `<div class="rail-section"><h3>Education</h3>${data.education
              .map(
                (e) => `<div class="rail-edu"><strong>${escape(e.school)}</strong><div>${escape(e.degree)}</div><div class="rail-dates">${escape(e.start)}${e.end ? " — " + escape(e.end) : ""}</div></div>`
              )
              .join("")}</div>`
          : ""
      }
    </aside>
    <main class="body">
      ${data.summary ? `<section><h2>Summary</h2><p>${escape(data.summary)}</p></section>` : ""}
      ${
        data.experience.length
          ? `<section><h2>Experience</h2>${data.experience
              .map(
                (e) => `<article class="entry">
                <div class="entry-head"><strong>${escape(e.role)}</strong><span class="dates">${escape(e.start)}${e.end ? " — " + escape(e.end) : ""}</span></div>
                <div class="entry-sub">${escape(e.company)}${e.location ? " · " + escape(e.location) : ""}</div>
                ${bullets(e.bullets)}
              </article>`
              )
              .join("")}</section>`
          : ""
      }
    </main>
  </div>`;
}

function editorial(data: ResumeContent, accent: string): string {
  return `
  <style>
    ${baseCss}
    body { background: #FAF6EC; color: #1B1916; font-family: "Fraunces", Georgia, serif; font-size: 10.5pt; line-height: 1.5; }
    .page { padding: 56px 60px; }
    h1 { font-style: italic; font-weight: 400; font-size: 44pt; line-height: 0.95; letter-spacing: -0.03em; margin: 0 0 6px; }
    .role { font-family: "IBM Plex Mono", monospace; font-style: normal; font-size: 9pt; letter-spacing: 0.18em; text-transform: uppercase; color: ${accent}; margin-bottom: 24px; }
    .cols { display: grid; grid-template-columns: 200px 1fr; gap: 36px; }
    h3 { font-family: "IBM Plex Mono", monospace; font-size: 8.5pt; letter-spacing: 0.18em; text-transform: uppercase; color: #1B1916; font-weight: 500; margin: 0 0 8px; }
    main h3 { color: ${accent}; }
    aside .block { margin-bottom: 22px; font-size: 10pt; line-height: 1.55; }
    main section { margin-bottom: 22px; }
    .entry { margin-bottom: 14px; }
    .entry-head { display: flex; justify-content: space-between; align-items: baseline; font-size: 12pt; }
    .entry-sub { font-style: italic; color: #6E6557; font-size: 10pt; margin-bottom: 4px; }
    .dates { font-family: "IBM Plex Mono", monospace; font-size: 9pt; letter-spacing: 0.06em; color: #6E6557; }
    ul { padding-left: 16px; margin: 4px 0 0; }
    aside .dates { font-family: "IBM Plex Mono", monospace; font-size: 8.5pt; color: #6E6557; }
  </style>
  <div class="page">
    <header><h1>${escape(data.name || "Your Name")}</h1><div class="role">${escape(data.role || "Your Title")}</div></header>
    <div class="cols">
      <aside>
        <div class="block"><h3>Contact</h3>
          ${[data.email, data.phone, data.location, data.website].filter(Boolean).map((c) => `<div>${escape(c)}</div>`).join("")}
        </div>
        ${
          data.skills.length
            ? `<div class="block"><h3>Skills</h3>${data.skills.map((s) => `<div>${escape(s)}</div>`).join("")}</div>`
            : ""
        }
        ${
          data.education.length
            ? `<div class="block"><h3>Education</h3>${data.education
                .map(
                  (e) => `<div class="edu"><strong>${escape(e.school)}</strong><div>${escape(e.degree)}</div><div class="dates">${escape(e.start)}${e.end ? " — " + escape(e.end) : ""}</div></div>`
                )
                .join("")}</div>`
            : ""
        }
      </aside>
      <main>
        ${data.summary ? `<section><h3>Summary</h3><p>${escape(data.summary)}</p></section>` : ""}
        ${
          data.experience.length
            ? `<section><h3>Experience</h3>${data.experience
                .map(
                  (e) => `<article class="entry">
                  <div class="entry-head"><strong>${escape(e.role)}</strong><span class="dates">${escape(e.start)}${e.end ? " — " + escape(e.end) : ""}</span></div>
                  <div class="entry-sub">${escape(e.company)}${e.location ? " · " + escape(e.location) : ""}</div>
                  ${bullets(e.bullets)}
                </article>`
                )
                .join("")}</section>`
            : ""
        }
      </main>
    </div>
  </div>`;
}

function whisper(data: ResumeContent, accent: string): string {
  const contact = [data.email, data.phone, data.location, data.website].filter(Boolean).map(escape).join("  /  ");
  return `
  <style>
    ${baseCss}
    body { background: white; color: #1B1916; font-family: "IBM Plex Sans", sans-serif; font-size: 10.5pt; line-height: 1.55; }
    .page { padding: 64px 64px; }
    h1 { font-size: 22pt; font-weight: 500; letter-spacing: -0.01em; margin: 0; text-transform: lowercase; }
    .role { font-size: 10pt; color: #6E6557; margin-top: 2px; text-transform: lowercase; }
    .contact { font-size: 9.5pt; color: #6E6557; margin-top: 14px; margin-bottom: 32px; }
    section { margin-bottom: 22px; }
    h2 { font-size: 10pt; font-weight: 500; color: #1B1916; margin: 0 0 10px; }
    h2::after { content: ""; display: inline-block; width: 16px; height: 1px; background: ${accent}; margin-left: 10px; vertical-align: middle; }
    .entry { margin-bottom: 12px; }
    .entry-head { display: flex; justify-content: space-between; align-items: baseline; font-size: 10.5pt; }
    .dates { font-size: 9pt; color: #6E6557; }
    ul { padding-left: 16px; margin: 4px 0 0; color: #3A352D; }
    li { margin-bottom: 2px; }
  </style>
  <div class="page">
    <header>
      <h1>${escape(data.name || "your name")}.</h1>
      <div class="role">${escape(data.role || "your title")}</div>
      ${contact ? `<div class="contact">${contact}</div>` : ""}
    </header>
    ${data.summary ? `<section><h2>summary</h2><p>${escape(data.summary)}</p></section>` : ""}
    ${
      data.experience.length
        ? `<section><h2>work</h2>${data.experience
            .map(
              (e) => `<article class="entry">
              <div class="entry-head"><span><strong>${escape(e.role)}</strong>, ${escape(e.company)}</span><span class="dates">${escape(e.start)}${e.end ? " — " + escape(e.end) : ""}</span></div>
              ${bullets(e.bullets)}
            </article>`
            )
            .join("")}</section>`
        : ""
    }
    ${
      data.education.length
        ? `<section><h2>education</h2>${data.education
            .map(
              (e) => `<div class="entry"><div class="entry-head"><span><strong>${escape(e.school)}</strong>, ${escape(e.degree)}</span><span class="dates">${escape(e.start)}${e.end ? " — " + escape(e.end) : ""}</span></div></div>`
            )
            .join("")}</section>`
        : ""
    }
    ${data.skills.length ? `<section><h2>tools</h2><p>${data.skills.map(escape).join(", ")}</p></section>` : ""}
  </div>`;
}

export function renderResumeHtml(templateId: string, data: ResumeContent, accent: string): string {
  let inner: string;
  switch (templateId) {
    case "sidebar":
      inner = sidebar(data, accent);
      break;
    case "editorial":
      inner = editorial(data, accent);
      break;
    case "whisper":
      inner = whisper(data, accent);
      break;
    case "broadsheet":
    default:
      inner = broadsheet(data, accent);
  }
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>${FONTS_LINK}<title>${escape(data.name || "Résumé")}</title></head><body>${inner}</body></html>`;
}
