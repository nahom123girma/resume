export type ResumeExperience = {
  id: string;
  company: string;
  role: string;
  location?: string;
  start: string; // free-form e.g. "Jan 2022"
  end: string; // "Present" or date
  bullets: string[];
};

export type ResumeEducation = {
  id: string;
  school: string;
  degree: string;
  start: string;
  end: string;
  notes?: string;
};

export type ResumeContent = {
  name: string;
  role: string;
  email: string;
  phone: string;
  location: string;
  website: string;
  summary: string;
  experience: ResumeExperience[];
  education: ResumeEducation[];
  skills: string[];
};

export const emptyResume: ResumeContent = {
  name: "",
  role: "",
  email: "",
  phone: "",
  location: "",
  website: "",
  summary: "",
  experience: [],
  education: [],
  skills: [],
};

export const sampleResume: ResumeContent = {
  name: "Maya Hernandez",
  role: "Senior Product Designer",
  email: "maya@example.com",
  phone: "(415) 555-0142",
  location: "San Francisco, CA",
  website: "federalresume.com/maya",
  summary:
    "Senior product designer with 8+ years shaping developer tools and B2B SaaS. I lead 0→1 work, partner closely with engineering, and care about how a product reads — from first impression to fifty-seventh use.",
  experience: [
    {
      id: "exp1",
      company: "Acme Cloud",
      role: "Senior Product Designer",
      location: "Remote",
      start: "Jan 2022",
      end: "Present",
      bullets: [
        "Led redesign of the developer console adopted by 12,000+ teams; improved task success by 31%.",
        "Built a portfolio of enterprise relationships, driving $2.1M in new pipeline.",
        "Shipped a typeset content system that cut design QA time by 40%.",
      ],
    },
    {
      id: "exp2",
      company: "Northwind Labs",
      role: "Product Designer",
      location: "Brooklyn, NY",
      start: "Aug 2018",
      end: "Dec 2021",
      bullets: [
        "Designed billing and onboarding flows used by 600k MAU.",
        "Partnered with 5 engineers to ship a self-serve plan upgrade flow worth $1.4M ARR.",
      ],
    },
  ],
  education: [
    {
      id: "edu1",
      school: "Rhode Island School of Design",
      degree: "B.F.A. Graphic Design",
      start: "2014",
      end: "2018",
    },
  ],
  skills: ["Product strategy", "Figma", "Design systems", "Prototyping", "User research", "Typography"],
};
