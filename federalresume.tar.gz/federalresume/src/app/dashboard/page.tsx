import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { redirect } from "next/navigation";
import Link from "next/link";
import { DashboardClient } from "@/components/builder/DashboardClient";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) redirect("/auth/login?callbackUrl=/dashboard");

  const resumes = await prisma.resume.findMany({
    where: { userId: session.user.id },
    orderBy: { updatedAt: "desc" },
    select: {
      id: true,
      title: true,
      templateId: true,
      accentColor: true,
      updatedAt: true,
    },
  });

  return (
    <main className="relative z-10 min-h-screen px-[clamp(20px,4vw,56px)] py-10">
      <div className="mx-auto max-w-[1100px]">
        <header className="mb-12 flex items-baseline justify-between">
          <Link href="/" className="flex items-baseline gap-[6px] font-serif text-[26px] font-semibold tracking-[-0.02em]">
            FederalResume<span className="ml-[2px] inline-block h-[7px] w-[7px] self-center rounded-full bg-amber" />
          </Link>
          <span className="text-sm text-ink-soft">{session.user.email}</span>
        </header>

        <div className="mb-10 flex items-end justify-between gap-6">
          <div>
            <h1 className="font-serif text-[clamp(36px,5vw,52px)] font-normal leading-[1.05] tracking-[-0.025em]">
              Your <em className="italic text-amber">résumés</em>.
            </h1>
            <p className="mt-2 text-ink-soft">Pick up where you left off, or start something new.</p>
          </div>
        </div>

        <DashboardClient
          initialResumes={resumes.map((r) => ({
            ...r,
            updatedAt: r.updatedAt.toISOString(),
          }))}
        />
      </div>
    </main>
  );
}
