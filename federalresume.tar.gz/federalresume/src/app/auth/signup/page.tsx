"use client";

import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { FormEvent, useState } from "react";

export default function SignupPage() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    const res = await fetch("/api/auth/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, password }),
    });

    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      setError(body.error ?? "Could not create account");
      setSubmitting(false);
      return;
    }

    const signInRes = await signIn("credentials", { email, password, redirect: false });
    setSubmitting(false);
    if (signInRes?.error) {
      setError("Account created — but auto-login failed. Please sign in.");
      router.push("/auth/login");
      return;
    }
    router.push("/dashboard");
    router.refresh();
  }

  return (
    <main className="relative z-10 min-h-screen px-6 py-16">
      <div className="mx-auto max-w-md">
        <Link href="/" className="mb-12 flex items-baseline gap-[6px] font-serif text-[26px] font-semibold tracking-[-0.02em]">
          FederalResume<span className="ml-[2px] inline-block h-[7px] w-[7px] self-center rounded-full bg-amber" />
        </Link>

        <h1 className="mb-2 font-serif text-[44px] font-normal leading-[1] tracking-[-0.025em]">
          Start <em className="italic text-amber">applying</em>.
        </h1>
        <p className="mb-10 text-ink-soft">Free forever for the basics.</p>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <Field label="Name">
            <input className="input" type="text" value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" />
          </Field>
          <Field label="Email">
            <input
              className="input"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
            />
          </Field>
          <Field label="Password">
            <input
              className="input"
              type="password"
              required
              minLength={8}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="new-password"
            />
            <span className="text-xs text-ink-mute">Minimum 8 characters.</span>
          </Field>

          {error && <p className="text-sm text-amber-deep">{error}</p>}

          <button
            type="submit"
            disabled={submitting}
            className="mt-2 inline-flex items-center justify-center gap-2 rounded-full bg-amber px-6 py-3 text-sm font-medium text-paper transition-all hover:-translate-y-px hover:bg-amber-deep disabled:opacity-60"
          >
            {submitting ? "Creating account…" : "Create account"}
          </button>
        </form>

        <p className="mt-8 text-sm text-ink-soft">
          Already have one?{" "}
          <Link href="/auth/login" className="border-b border-amber pb-px italic text-amber">
            Sign in
          </Link>
        </p>
      </div>

      <style jsx>{`
        .input {
          width: 100%;
          padding: 12px 14px;
          background: var(--paper, #faf6ec);
          border: 1px solid var(--rule, #d9cfb8);
          border-radius: 10px;
          font-family: "IBM Plex Sans", sans-serif;
          font-size: 15px;
          color: #1b1916;
          transition: border-color 0.15s;
        }
        .input:focus {
          outline: none;
          border-color: #1b1916;
        }
      `}</style>
    </main>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="flex flex-col gap-2">
      <span className="font-mono text-[11px] uppercase tracking-[0.14em] text-ink-mute">{label}</span>
      {children}
    </label>
  );
}
