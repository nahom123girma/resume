import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { redirect, notFound } from "next/navigation";
import { ResumeBuilder } from "@/components/builder/ResumeBuilder";
import type { ResumeContent } from "@/types/resume";

export const dynamic = "force-dynamic";

export default async function ResumePage({ params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) redirect(`/auth/login?callbackUrl=/resume/${params.id}`);

  const resume = await prisma.resume.findFirst({
    where: { id: params.id, userId: session.user.id },
  });
  if (!resume) return notFound();

  return (
    <ResumeBuilder
      id={resume.id}
      initialTitle={resume.title}
      initialTemplateId={resume.templateId}
      initialAccent={resume.accentColor}
      initialContent={resume.content as unknown as ResumeContent}
    />
  );
}
