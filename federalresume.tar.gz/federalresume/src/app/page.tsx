import { Nav } from "@/components/landing/Nav";
import { Hero } from "@/components/landing/Hero";
import { TrustBar } from "@/components/landing/TrustBar";
import { Templates } from "@/components/landing/Templates";
import { Results } from "@/components/landing/Results";
import { Features } from "@/components/landing/Features";
import { FinalCTA } from "@/components/landing/FinalCTA";
import { Footer } from "@/components/landing/Footer";
import { FloatingCTA } from "@/components/landing/FloatingCTA";

export default function HomePage() {
  return (
    <>
      <Nav />
      <main>
        <Hero />
        <TrustBar />
        <Templates />
        <Results />
        <Features />
        <FinalCTA />
      </main>
      <Footer />
      <FloatingCTA />
    </>
  );
}
