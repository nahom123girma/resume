import type { Metadata } from "next";
import "./globals.css";
import { Providers } from "./providers";

export const metadata: Metadata = {
  title: "FederalResume — Job-winning résumé builder",
  description:
    "Build a job-winning résumé 2× as fast. Choose typeset templates, generate content with AI, and apply in minutes.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body data-paper="true">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
