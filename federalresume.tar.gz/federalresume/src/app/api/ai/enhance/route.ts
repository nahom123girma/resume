import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import OpenAI from "openai";
import { z } from "zod";

const Body = z.object({
  text: z.string().min(3).max(800),
  context: z.string().max(1500).optional(),
});

const SYSTEM_PROMPT = `You rewrite résumé bullet points to be ATS-friendly and impactful.

Rules:
- Lead with a strong action verb in past tense (or present tense for current role).
- Quantify impact with concrete numbers, percentages, dollars, or scope where plausible.
- Avoid clichés ("team player", "results-driven", "synergize"), buzzwords, and AI-tells.
- Keep each rewrite under 28 words. Single sentence, no bullet glyph.
- Never invent specific employer names, dollar amounts, or metrics not implied in the input. Use ranges like "$1M+" or "30%+" when reasonable, otherwise omit numbers.

Return strictly valid JSON in this shape:
{"rewrites": ["...", "...", "..."]}
Three rewrites. Different angles: one quantified, one scope/scale, one outcome-focused.`;

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  if (!process.env.OPENAI_API_KEY) {
    return NextResponse.json(
      { error: "OPENAI_API_KEY not configured on the server" },
      { status: 503 }
    );
  }

  const body = await req.json().catch(() => null);
  const parsed = Body.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Invalid input" }, { status: 400 });

  const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

  const userMsg = parsed.data.context
    ? `Role context: ${parsed.data.context}\n\nBullet to rewrite:\n${parsed.data.text}`
    : `Bullet to rewrite:\n${parsed.data.text}`;

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      temperature: 0.6,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: userMsg },
      ],
    });

    const raw = completion.choices[0]?.message?.content ?? "{}";
    let parsedJson: { rewrites?: unknown };
    try {
      parsedJson = JSON.parse(raw);
    } catch {
      return NextResponse.json({ error: "Model returned invalid JSON" }, { status: 502 });
    }
    const rewrites = Array.isArray(parsedJson.rewrites)
      ? (parsedJson.rewrites as unknown[]).filter((x): x is string => typeof x === "string").slice(0, 5)
      : [];
    return NextResponse.json({ rewrites });
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : "OpenAI request failed";
    console.error("AI enhance error", e);
    return NextResponse.json({ error: msg }, { status: 502 });
  }
}
