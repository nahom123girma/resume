import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { emptyResume, sampleResume } from "@/types/resume";

async function requireUserId() {
  const session = await getServerSession(authOptions);
  return session?.user?.id ?? null;
}

export async function GET() {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const resumes = await prisma.resume.findMany({
    where: { userId },
    orderBy: { updatedAt: "desc" },
    select: {
      id: true,
      title: true,
      templateId: true,
      accentColor: true,
      updatedAt: true,
      createdAt: true,
    },
  });
  return NextResponse.json({ resumes });
}

export async function POST(req: NextRequest) {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json().catch(() => ({}));
  const seedSample = body.sample === true;

  const resume = await prisma.resume.create({
    data: {
      userId,
      title: body.title || "Untitled résumé",
      templateId: body.templateId || "broadsheet",
      accentColor: body.accentColor || "#C44A1A",
      content: seedSample ? sampleResume : emptyResume,
    },
  });
  return NextResponse.json({ resume }, { status: 201 });
}
