import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { renderResumeHtml } from "@/lib/pdfTemplates";
import type { ResumeContent } from "@/types/resume";

export const runtime = "nodejs";
export const maxDuration = 30;

async function getBrowser() {
  // Detect serverless (Vercel/AWS Lambda) by AWS_LAMBDA_FUNCTION_NAME or VERCEL_ENV.
  const isServerless = !!process.env.AWS_LAMBDA_FUNCTION_NAME || !!process.env.VERCEL_ENV;

  if (isServerless) {
    // Lazy import to avoid bundling chromium-min in dev.
    const chromium = (await import("@sparticuz/chromium")).default;
    const puppeteer = (await import("puppeteer-core")).default;
    const remote = process.env.CHROMIUM_REMOTE_URL;
    const executablePath = remote
      ? await chromium.executablePath(remote)
      : await chromium.executablePath();
    return puppeteer.launch({
      args: chromium.args,
      defaultViewport: chromium.defaultViewport,
      executablePath,
      headless: true,
    });
  }

  // Local dev: use whatever Chrome/Chromium is on the system.
  const puppeteer = (await import("puppeteer-core")).default;
  const localCandidates = [
    process.env.CHROME_PATH,
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/usr/bin/google-chrome",
    "/usr/bin/chromium",
    "/usr/bin/chromium-browser",
  ].filter(Boolean) as string[];
  const executablePath = localCandidates.find(Boolean);
  if (!executablePath) {
    throw new Error(
      "No local Chrome found. Set CHROME_PATH env var, install Chrome, or run inside the production serverless config."
    );
  }
  return puppeteer.launch({ executablePath, headless: true, args: ["--no-sandbox"] });
}

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const resume = await prisma.resume.findFirst({
    where: { id: params.id, userId: session.user.id },
  });
  if (!resume) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const html = renderResumeHtml(resume.templateId, resume.content as unknown as ResumeContent, resume.accentColor);

  let browser: Awaited<ReturnType<typeof getBrowser>> | null = null;
  try {
    browser = await getBrowser();
    const page = await browser.newPage();
    await page.setContent(html, { waitUntil: "networkidle0" });
    const pdf = await page.pdf({
      format: "letter",
      printBackground: true,
      margin: { top: "0", bottom: "0", left: "0", right: "0" },
    });
    await browser.close();

    const slug = (resume.title || "resume").toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 60);
    return new NextResponse(pdf as unknown as BodyInit, {
      status: 200,
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="${slug}.pdf"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (e) {
    if (browser) await browser.close().catch(() => {});
    console.error("PDF render error", e);
    const msg = e instanceof Error ? e.message : "PDF rendering failed";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
