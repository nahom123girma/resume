# FederalResume

A typeset résumé builder. Pick a template, write content (or let AI rewrite it), export a clean PDF.

This repo is a Next.js 14 (App Router) application with Prisma + PostgreSQL, NextAuth credentials auth, OpenAI for content enhancement, and Puppeteer for PDF export.

The landing page is converted faithfully from the original editorial HTML — cream / amber / Fraunces is the brand, and that aesthetic carries into the auth pages, dashboard, and builder.

## What's in here

- **Landing page** (`/`) — hero, trust bar, four-template showcase, six features, results section, footer. All converted into focused React components under `src/components/landing/`.
- **Auth** (`/auth/login`, `/auth/signup`) — NextAuth credentials provider with bcrypt-hashed passwords.
- **Dashboard** (`/dashboard`) — list, create, delete résumés. "Use the sample" seeds a worked example.
- **Builder** (`/resume/[id]`) — split-pane editor with live preview, template switcher, accent-color picker, autosave every 5 seconds, AI bullet rewrites, floating save button, and PDF export.
- **Four templates** — Broadsheet (classic newsprint), Sidebar (modern with colored rail), Editorial (italic display, two-column), Whisper (minimal sans). Each lives in `src/components/templates/` for the live preview, with parallel HTML-string generators in `src/lib/pdfTemplates.ts` for PDF rendering.
- **API routes**:
  - `POST /api/auth/signup` — create account
  - `[...nextauth]` — NextAuth handlers
  - `GET/POST /api/resumes` — list + create
  - `GET/PATCH/DELETE /api/resumes/[id]` — read, update, delete
  - `GET /api/resumes/[id]/pdf` — render PDF via Puppeteer
  - `POST /api/ai/enhance` — rewrite a bullet via OpenAI

## Quick start

```bash
# 1. Install
npm install

# 2. Configure
cp .env.example .env
# Then edit .env with your DATABASE_URL, NEXTAUTH_SECRET, OPENAI_API_KEY.

# Generate a secret:
#   openssl rand -base64 32

# 3. Push the schema to your database
npx prisma db push

# 4. Run dev server
npm run dev
# → http://localhost:3000
```

## Environment variables

| Var | Required | What it does |
|---|---|---|
| `DATABASE_URL` | Yes | PostgreSQL connection string. Use Supabase, Neon, Railway, or local Postgres. |
| `NEXTAUTH_URL` | Yes (prod) | Your site URL, e.g. `https://federalresume.com`. |
| `NEXTAUTH_SECRET` | Yes | Session-signing secret. Generate with `openssl rand -base64 32`. |
| `OPENAI_API_KEY` | For AI features | OpenAI key. The `Enhance with AI` button is disabled cleanly if unset. |
| `CHROMIUM_REMOTE_URL` | Production only | URL to a hosted Chromium tarball for serverless PDF rendering (see _Deploying_). |
| `CHROME_PATH` | Local override | Optional path to a local Chrome binary if auto-detect fails. |

## Tech stack notes

- **Next.js 14** App Router with route handlers — single deployable unit.
- **Prisma + PostgreSQL** — `User` and `Resume` models in `prisma/schema.prisma`. Resume content stored as `Json`.
- **NextAuth** with the Credentials provider, JWT session strategy. Add OAuth providers in `src/lib/auth.ts` if needed.
- **OpenAI** `gpt-4o-mini` for bullet rewrites — three rewrites per call, JSON-mode response, system prompt that bans clichés and invented numbers.
- **Puppeteer** with `@sparticuz/chromium` for serverless PDFs. The PDF route renders an HTML string per template (parallel to but separate from the React preview templates) — this is the most reliable approach with Puppeteer and avoids SSR-of-styled-jsx headaches.
- **Tailwind** with the editorial palette extended into the theme. Fonts: Fraunces (display/serif), IBM Plex Sans (body), IBM Plex Mono (small caps), Caveat (signature).

## Deploying

### Vercel + Neon/Supabase (recommended)

1. Push to GitHub.
2. Import the repo into Vercel.
3. Set env vars in Vercel project settings: `DATABASE_URL`, `NEXTAUTH_URL`, `NEXTAUTH_SECRET`, `OPENAI_API_KEY`, `CHROMIUM_REMOTE_URL`.
4. For PDF in serverless: use the [Sparticuz Chromium release tarball URL](https://github.com/Sparticuz/chromium/releases) for `CHROMIUM_REMOTE_URL`. The function in `src/app/api/resumes/[id]/pdf/route.ts` detects Vercel via `VERCEL_ENV` and uses the bundled chromium accordingly.
5. Run `npx prisma db push` once against the production database (or set up a migration in `prisma/migrations/`).

### Local PDF

In dev, the route looks for Chrome in standard locations or honors `CHROME_PATH`. Install Google Chrome on your machine for local PDF testing — or just deploy and test there.

## Repo layout

```
prisma/schema.prisma        Database schema
src/app/                    Next.js App Router pages & API routes
  page.tsx                  Landing
  auth/{login,signup}       Auth pages
  dashboard/page.tsx        Dashboard (server)
  resume/[id]/page.tsx      Builder host (server)
  api/...                   Route handlers
src/components/
  landing/                  Marketing components
  builder/ResumeBuilder.tsx The editor with autosave
  builder/DashboardClient.tsx
  templates/                React templates (live preview)
src/lib/
  prisma.ts                 Prisma client singleton
  auth.ts                   NextAuth config
  templates.ts              Template definitions / accent palette
  pdfTemplates.ts           HTML-string renderers for the PDF route
src/types/resume.ts         Resume shape + sample data
```

## MVP feature checklist

- [x] Landing page (responsive, faithful to the editorial design)
- [x] Auth (sign up / log in / sign out)
- [x] Save & load multiple résumés per account
- [x] Resume builder with live preview
- [x] Four selectable templates
- [x] Per-resume accent color
- [x] AI bullet rewrite (`✦ AI` on every bullet — three options to choose from)
- [x] Autosave every 5 seconds + on tab close
- [x] PDF export (`/api/resumes/[id]/pdf`)
- [x] Sticky CTA, floating save button, mobile preview toggle

## Honest gotchas to know about

- The landing page and the template previews are styled with a mix of Tailwind utilities and `styled-jsx`. The PDF route deliberately uses parallel **string** templates (`src/lib/pdfTemplates.ts`) rather than SSR'ing the React templates — this is more reliable across Puppeteer environments. If you change the visual design of a template, update both.
- The Credentials provider is fine for an MVP. For production, consider adding email verification and switching primary auth to OAuth (Google/GitHub) — both straightforward additions in `src/lib/auth.ts`.
- The AI route returns up to 5 rewrites; the UI shows whatever the model returned (typically 3). Tighten the system prompt or response format if you want stricter shape.

---

© 2026 FederalResume Inc. Designed in Brooklyn. Typeset everywhere.
