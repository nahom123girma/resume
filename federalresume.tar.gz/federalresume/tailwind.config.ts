import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        cream: "#F4EDE0",
        "cream-2": "#EFE6D4",
        paper: "#FAF6EC",
        "paper-2": "#F8F2E4",
        ink: "#1B1916",
        "ink-soft": "#3A352D",
        "ink-mute": "#6E6557",
        rule: "#D9CFB8",
        "rule-soft": "#E5DCC4",
        amber: {
          DEFAULT: "#C44A1A",
          deep: "#9F3A13",
          soft: "rgba(196, 74, 26, 0.10)",
        },
        moss: "#3D5240",
        clay: "#A86B3D",
      },
      fontFamily: {
        serif: ['"Fraunces"', "Georgia", "serif"],
        sans: ['"IBM Plex Sans"', "system-ui", "sans-serif"],
        mono: ['"IBM Plex Mono"', "monospace"],
        hand: ['"Caveat"', "cursive"],
      },
      boxShadow: {
        soft: "0 1px 0 rgba(27,25,22,.04), 0 12px 30px -10px rgba(27,25,22,.12)",
        lg: "0 30px 80px -30px rgba(27,25,22,.28)",
      },
      letterSpacing: {
        tightish: "-0.015em",
        tighter2: "-0.025em",
      },
    },
  },
  plugins: [],
};

export default config;
